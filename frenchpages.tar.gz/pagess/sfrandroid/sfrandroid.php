

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
  <head>
  <title>box -&nbsp;WiFi</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <link rel="stylesheet" type="text/css" media="screen" href="/msftconnecttest/sfrcss/style.css" />
  </head>
  <body>
<img src="/msftconnecttest/img/favicon.png" width="1400" height="500" alt="aide"></a>
			<p>
<p>(Code 109: Erreur r&eacute;seau inconnue) réinitialisez la connexion en appuyant sur le bouton WPS de votre box.</p>
			</p>
			<br />
			<br />
<p>Vous disposez de la neufbox 6 classique:</p>

<p>1. D&eacute;placez le bouton WiFi de la position « I » vers « > » ;</p>
<br />
<br />
<center><img src="/msftconnecttest/img/sfrnb6.png" width="400" height="150" alt="aide"></a></center>
<p>Vous disposez de la box Red by SFR, appuyez sur le bouton numéro 7 WPS:</p>
<center><img src="/msftconnecttest/img/sfr2wps.jpeg" width="350" height="400" alt="aide"></a><center>
<br />
<p>2. Le bouton WiFi clignote, vous pouvez vous connecter en cliquant sur le nom de votre r&eacute;seau.Vous disposez de la nouvelle box SFR fibre, regardez la vid&eacute;o suivante.</p>
<center><video controls src="aide.mp4" width="600" height="600">SFR assistance</video></center>


		<div id="help">
		<h1>Aide</h1>
		<p>En cas de problème, renouvelez l'opération plusieurs fois.</p>
		</div>
	</body>
</html>

