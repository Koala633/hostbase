#!/usr/bin/env ruby


require 'gtk2'
require 'open3'
require 'highline/import'


def error
puts "\e[1;31m[*] ERROR detected: check ALL your entry will abort in 5s.\e[0m"
sleep 5
abort("BYE..")
end

# déclaration globales des variables a utiliser de manière a éviter les fonctions récurrentes.


File.open("apcanal.txt").readlines.each do |apcanal|
   puts apcanal
$apcanal = apcanal.chomp
if apcanal.chomp.to_i.between?(1, 13)
   puts "\e[1;32m[*] Ap channel is OK.\e[0m"
else
error()
end
end

File.open("apmac.txt").readlines.each do |apmac|
   puts apmac
$apmac = apmac.chomp
if apmac.chomp =~ /^([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}$/i
   puts "\e[1;32m[*] Ap mac is OK.\e[0m"
else
error()
end
end


File.open("carte.txt").readlines.each do |carte|
   puts carte
$carte = carte.chomp
if carte.chomp.start_with?('wlan', 'wlx', 'wlp')
   puts "\e[1;32m[*] Wifi card is OK.\e[0m"
else
error()
end
end

page = "page.txt"
if File.exist?("page.txt")
page = File.open("page.txt").readlines.each do |page|
  puts page
$page = page.chomp
if page.chomp.start_with?('livebox', 'sfr', 'bbox', 'free')
   puts "\e[1;32m[*] Phishing page is OK.\e[0m"
else
error()
end
end

File.open("canal.txt").readlines.each do |canal|
   puts canal
$canal = canal.chomp
if canal.chomp.to_i.between?(1, 13)
   puts "\e[1;32m[*] Channel is OK.\e[0m"
else
error()
end
end


File.open("ssid.txt").readlines.each do |ssid|
   puts ssid
$ssid = ssid.chomp

file = "mac.txt"
if File.exist?("mac.txt")
file = File.open("mac.txt").readlines.each do |mac|
   puts mac
$mac = mac.chomp
if mac.chomp =~ /^([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}$/i
   puts "\e[1;32m[*] Your mac is OK.\e[0m"
else
error()
end
end
end
end
end

Dir.chdir '/tmp/hostbase-1.1EN'
sleep 1
`touch cartedos.txt`

system "airmon-ng > airmon-ng.txt"

File.open("airmon-ng.txt").readlines.each do |line|
  if line =~ /ath/
$line = puts line.split.first
$line = line.split.first.chomp
end
end


if $line === "phy0"
puts "atheros card detected on wlan0, switching wlan1 to avoid conflict with hostapd and the other card"
`ifconfig wlan1 down`
        `ip link set wlan1 name wlan5`
        `ifconfig wlan5 up`
         sleep 4
end
if $line === "phy1"
puts "atheros card detected on wlan1, switiching it to wlan0"
`ifconfig wlan0 down`
        `ip link set wlan0 name wlan5`
        `ifconfig wlan5 up`
        sleep 4
`ifconfig wlan1 down`
        `ip link set wlan1 name wlan0`
        `ifconfig wlan0 up`
         sleep 4

end
if $line === "phy2"
puts "atheros card detected on wlan2, switiching it to wlan0"
`ifconfig wlan0 down`
        `ip link set wlan0 name wlan5`
        `ifconfig wlan5 up`
         sleep 4
`ifconfig wlan2 down`
        `ip link set wlan2 name wlan0`
        `ifconfig wlan0 up`
         sleep 4
end

