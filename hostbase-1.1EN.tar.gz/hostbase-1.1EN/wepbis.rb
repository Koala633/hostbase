#!/usr/bin/env ruby


require 'gtk2'
require 'open3'
require 'highline/import'


def error
puts "\e[1;31m[*] ERROR detected: check ALL your entry will abort in 5s.\e[0m"
sleep 5
abort("BYE..")
end


puts "Stoping trouble process... wait..."
`airmon-ng check kill`
sleep 8


File.open("carte.txt").readlines.each do |carte|
   puts carte
$carte = carte.chomp
if carte.chomp.start_with?('wlan', 'wlx', 'wlp')
   puts "\e[1;32m[*] Wifi card is OK.\e[0m"
else
error()
end
end


File.open("canal.txt").readlines.each do |canal|
   puts canal
$canal = canal.chomp
if canal.chomp.to_i.between?(1, 13)
   puts "\e[1;32m[*] Channel of AP 1 is OK.\e[0m"
else
error()
end
end


File.open("mac.txt").readlines.each do |mac|
   puts mac
$mac = mac.chomp
if mac.chomp =~ /^([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}$/i
   puts "\e[1;32m[*] Your first mac is OK.\e[0m"
else
error()
end
end


File.open("ssid.txt").readlines.each do |ssid|
   puts ssid
$ssid = ssid.chomp
puts "\e[1;32m[*] SSID 1 is OK.\e[0m"




file = "apmacbis.txt"
if File.exist?("apmacbis.txt")
file = File.open("apmacbis.txt").readlines.each do |apmacbis|
  puts apmacbis
$apmacbis = apmacbis.chomp
if apmacbis.chomp =~ /^([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}$/i
   puts "\e[1;32m[*] Ap mac number 2 is OK.\e[0m"
else
error()
end
end
end


file = "apcanalbis.txt"
if File.exist?("apcanalbis.txt")
file = File.open("apcanalbis.txt").readlines.each do |apcanalbis|
  puts apcanalbis
$apcanalbis = apcanalbis.chomp
if apcanalbis.chomp.to_i.between?(1, 13)
   puts "\e[1;32m[*] Channel of ap 2 is OK.\e[0m"
else
error()
end
end
end


File.open("ssidbis.txt").readlines.each do |ssidbis|
   puts ssidbis
$ssidbis = ssidbis.chomp
puts "\e[1;32m[*] SSID 2 is OK.\e[0m"

File.open("apmac.txt").readlines.each do |apmac|
   puts apmac
$apmac = apmac.chomp
if apmac.chomp =~ /^([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}$/i
   puts "\e[1;32m[*] Ap mac number 1 is OK.\e[0m"
else
error()
end
end
end




file = "adressmac2.txt"
if File.exist?("adressmac2.txt")
file = File.open("adressmac2.txt").readlines.each do |adressmac2|
  puts adressmac2
$adressmac2 = adressmac2.chomp
if adressmac2.chomp =~ /^([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}$/i
   puts "\e[1;32m[*] Your second MAC is OK.\e[0m"
else
error()
end
end
end




File.open("apcanal.txt").readlines.each do |apcanal|
   puts apcanal
$apcanal = apcanal.chomp
if apcanal.chomp.to_i.between?(1, 13)
   puts "\e[1;32m[*] Channel of AP 2 is OK.\e[0m"
else
error()
end
end
end
