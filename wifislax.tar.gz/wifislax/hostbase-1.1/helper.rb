#!/usr/bin/env ruby


require 'gtk2'
require 'open3'
require 'highline/import'




system "airmon-ng >> airmonng.txt"

File.open("airmonng.txt").readlines.each do |line|
  if line =~ /ath/
nil
else
puts "\e[1;31m[*] ERROR: No atheros card detected, hostapd work with atheros driver ! use airbase-ng\e[0m"
end
end


system "gem list > gemlist.txt"
File.open("gemlist.txt").readlines.each do |gem|
if File.read("gemlist.txt").include? ('gtk2') && ('highline')
nil
else
puts "\e[1;31m[*] ERROR: Some important ruby gems are missing\e[0m"
end
end


if Dir.exists?('/var/www/html')
puts "\e[1;31m[*] ERROR: The apache2 web server need to be configured as DocumentRoot /var/www/ check that on /etc/apache2/sites-enabled/000-default.conf\e[0m"
else
nil
end


system "ps aux | grep network-manager > net.txt"
File.open("net.txt").readlines.each do |net|
if File.zero?("net.txt")
nil
else
puts "\e[1;31m[*] ERROR: network-manager must be down to use hostapd\e[0m"
end
end


system "ruby -v > version.txt"
File.open("version.txt").readlines.each do |net|
if File.read("version.txt").include? ('ruby 2.3.6p384 (2017-12-14) [x86_64-linux-gnu]')
nil
else
puts "\e[1;32m[*] INFO: Your ruby version is not the same from the script building, it maybe no matter but check that\e[0m"
end
end


puts "\e[1;32m[*] INFO: A file process.txt has been created on this folder, for any problem post the output on websites with all the return of this windows\e[0m"
system "ps -ef > process.txt"
sleep 1























