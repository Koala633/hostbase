<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
					"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>Ayuda Jazztel</title>
        <link rel="stylesheet" type="text/css" href="jazztel.css" />
   </head>
<body>
<img src="jazztel2.png" />
<p>Error 109: se tiene que reiniciar el wifi pulsando el botón “WPS”.</p>
<div class="imagecentre">
    <img alt="" src="jazztel3.png">
    <img alt="" src="aidewps.png">
</br>
</br>
<p>Con los nuevos router el botón “WPS” se encontra en el lado izquierdo.<p>
<p></strong> <a href="/msftconnecttest/jazzshout/jazztchat.php" target="_blank"><u>Ayuda en linea</u> ...</a></p>
<img class="zte" src="wpsjazztel.png" />
</div>
</body>
</html>
