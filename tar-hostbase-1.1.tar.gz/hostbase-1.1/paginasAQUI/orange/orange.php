<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
	<head>
		<title>Interfaz de Orange</title>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta http-equiv="Content-language" content="fr">
		<meta name="author" content="Nicolas VIVIEN">
		<meta name="Copyright" content="SAGEM COMMUNICATIONS">
		<link rel="stylesheet" type="text/css" href="/msftconnecttest/ocss/fonts.css">
		<link rel="stylesheet" type="text/css" href="/msftconnecttest/ocss/page.css">
		<link rel="stylesheet" type="text/css" href="/msftconnecttest/ocss/menu.css">
		<link rel="stylesheet" type="text/css" href="/msftconnecttest/ocss/header.css">
		<link rel="stylesheet" type="text/css" href="/msftconnecttest/ocss/contener.css">
		<link rel="stylesheet" type="text/css" href="/msftconnecttest/ocss/subcontener.css">
		<link rel="stylesheet" type="text/css" href="/msftconnecttest/ocss/array.css">
		<link rel="stylesheet" type="text/css" href="/msftconnecttest/ocss/hardware.css">
		<link rel="stylesheet" type="text/css" href="/msftconnecttest/ocss/button.css">
		<link rel="stylesheet" type="text/css" href="/msftconnecttest/ocss/lbpopup.css">
		<link rel="stylesheet" type="text/css" href="/msftconnecttest/ocss/progressbar.css">
		<link rel="stylesheet" type="text/css" href="/msftconnecttest/ocss/styles.css">
                <link rel="stylesheet" href="/msftconnecttest/ocss/livebox.css" type="text/css" media="screen"/>
		<script type="text/javascript" src="/msftconnecttest/ojs/script.js"></script>
		<script type="text/javascript" src="/msftconnecttest/ojs/control.js"></script>
		<script type="text/javascript" src="/msftconnecttest/ojs/progressbar.js"></script>
		<script type="text/javascript" src="/msftconnecttest/ojs/LBPopup.js"></script>
		<script type="text/javascript" src="/msftconnecttest/ojs/dragresize.js"></script>
		<script type="text/javascript" src="/msftconnecttest/ojs/md5.js"></script>
	</head>
	<body>
		<div id="GUI_master">
		<div class="main">
<script>
createLBPopup();
js_esp_ConfirmDialogTitle = "Confirmation";
js_esp_ConfirmDialogText = "Etes-vous sûr de vouloir quitter sans enregistrer les changements ?";
js_esp_ConfirmDialogYes = "Oui";
js_esp_ConfirmDialogNo = "Non";
js_mbv_ConfirmActions = "1";
</script>
<table class="main">
	<tr>
		<td class="header">
			<div id="header">
				<h4>livebox</h4>
				<ul id="rubrics">
					<li id="rubric1" class="left_rub" style="z-index:1;" onmouseOver="setClasseNameS(this,'left_mouseOver');" onmouseOut="setClasseNameS(this,'left_mouseOut');">Inicio</li>
					<li id="rubric2" class="right_rub_selected" style="left:120px; z-index:2;" onmouseOver="setClasseNameS(this,'right_mouseOver');" onmouseOut="setClasseNameS(this,'right_mouseOut');">configuración</li>
				</ul>
			</div>

</td>
	</tr>
	<tr>
		<td colspan="2" class="authinfo">
<span class="authusername">Administración</span>
(<a href="" class="authlinklogout">cerrar sesión</a>)
		</td>
	</tr>
</table>
<style>
#header {
  width: 915;
}
#contener table.contener {
  width: 735px;
}
#subcontener table.subcontener {
  width: 695px;
}
#array input {
  text-align: center;
}
</style>
<script>
 function  ConfirmNoSecurityPopUp(wifistatus, broadcast, easypairing, wpspairing, wpspincode, wpspush, wifipush, ssid, key, mode, channel, nbr, mac){
  var lastvalue;
  // Change text...
  js_esp_ConfirmDialogTitle = "Mode WiFi non sécurisé";
  js_esp_ConfirmDialogText = "Le filtrage par adresse MAC est activé automatiquement. Il faut entrer votre adresse MAC dans la liste.";
  lastvalue = showWarningPopup;
  showWarningPopup = 1;
  GoPage('index.cgi?page=wireless&action=setnosecurity&wifistatus=' + wifistatus + '&broadcast=' + broadcast + '&easypairing=' + easypairing + ' &wpspairing=' + wpspairing + '&wpspincode =' + wpspincode + '&wpspush=' + wpspush + '&wifipush=' + wifipush + '&ssid='+ ssid + '&key='+key+'&mode=' + mode + '&channel=' + channel + '&nbr=' + nbr + '&mac=' + mac + '&sessionid=6fb37ufaAnDEDgwJzAFQoR1PJzn44rp');
  showWarningPopup = lastvalue;
  // Change text...
  js_esp_ConfirmDialogTitle = "Confirmation";