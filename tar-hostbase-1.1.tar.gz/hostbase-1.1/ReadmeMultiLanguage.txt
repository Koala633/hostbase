
~~~~~~~~~~~~~~~~~~ Hostbase project By Koala @ crack-wifi.com @ wifi-libre.com @ kali-linux.fr ~~~~~~~~~~~~~~~~~~~~

Welcome to the hostbase project// Bienvenido en hostbase// Bienvenu sur le projey hostbase.

INSTALL FOR ALL/PARA TODOS/POUR TOUT LE MONDE:

apt-get install -y build-essential upgrade-system subversion wget g++ iptables iptables-dev pavucontrol ffmpeg sqlite3 libsqlite3-dev libssl-dev libnl-3-dev libnl-genl-3-dev dsniff hostapd isc-dhcp-server pkg-config xterm freeradius apache2 php libapache2-mod-php php-mcrypt php-cli tcpdump scapy vokoscreen wireshark python-twisted bridge-utils devscripts gengetopt autoconf libtool make



ES: para usar el modo multi AP o combo se necesita compilar bien hostapd.Si tienes una version de hostapd antigua suprima lo:
apt-get remove hostapd

Y compila lo asi:

wget http://hostap.epitest.fi/releases/hostapd-2.6.tar.gz
tar -zxf hostapd-2.6.tar.gz
cd /root/hostapd-2.6/hostapd
cp defconfig .config
nano .config

Decomentar el # en todas las opciones que siguen:

CONFIG_DRIVER_NL80211=y
CONFIG_LIBNL32=y
CONFIG_EAP_PWD=y
CONFIG_WPS=y
CONFIG_WPS_UPNP=y
CONFIG_WPS_NFC=y
CONFIG_RADIUS_SERVER=y
CONFIG_IEEE80211N=y
CONFIG_IEEE80211AC=y
CONFIG_DEBUG_FILE=y
CONFIG_FULL_DYNAMIC_VLAN=y
CONFIG_TLSV11=y
CONFIG_TAXONOMY=y


Y termina con:

sudo make
sudo make install
hostapd -v



EN/ES/FR ruby graphic interface install:

If you already have the fake pages in /etc you just need to install the following ruby gems:

apt-get install ruby
apt-get install ruby-dev
gem install highline
apt-get install libgtk2.0-dev
gem install gtk2

Si tienes ya la version 1.0 tienes que installar los gems de ruby:

apt-get install ruby
apt-get install ruby-dev
gem install highline
apt-get install libgtk2.0-dev
gem install gtk2


Si vous avez déja la version 1.0 il vous faut installer les gems de ruby:

apt-get install ruby
apt-get install ruby-dev
gem install highline
apt-get install libgtk2.0-dev
gem install gtk2


In case of troubleshooting during install//Si tienes problemo de installacion//En cas de problème d'installation:

gem install rake
gem install bundler

Then try to install again the ruby gems above//Despues reinicia las installacion de los gem de ruby a riba//Ensuite recommencez l'installation des ruby gems ci-dessus.


____________________________________________________

EN/ES/FR start:

The script need to be started in /tmp folder //El script se tiene que ejecutar en la carpeta /tmp //Le script doit etre lancé dans /tmp
Just copy/paste the entire folder of hostbase-1.1 to /tmp // Copia y pega la carpeta entera de hostbase-1.1 a dentro la carpeta /tmp // Copiez/coller le dossier hostbase-1.1 dans /tmp


In /tmp/hostbase-1.1 folder, right click and open a shell here// A dentro /tmp/hostbase-1.1 click derecho, abrir un terminal aqui // Dans /tmp/hostbase-1.1, clique droit ouvrir un terminal ici.


Start it // Inicia lo asi // lancer le tel que:
ruby hostbase.rb


--> No olvidas de empezar por el scan de redes para apagar network-manager <--


____________________________________________________

EN/ES/FR the bascis knowledge:


EN: For better performance this script works ONLY with 2 wifi-cards cause it automatise a lot of thing like the encrypted AP with WPS the active DoS tracking the AP channel etc...

ES: Para mas potentia este script ANDA con 2 tarjeta wifi porqué automatisa un monton de cosas: el AP encryptado con el WPS, la DoS que sigue el Ap etc...

FR: Pour une meilleur performance ce script fonctionne SEULEMENT avec 2 cartes wifi, automatisation de la rogue AP et du WPS, de la DoS qui suit l'ap sur son canal etc... c'est mieux ainsi.2 cartes wifi c'est pas de trop et ça coute aps très cher, il faut savoir ce qu'on veut comme compromis, soit avoir une chance de réussir l'attaque soit la foirer.


You need to start with the scan option to stop network-manager and grab network info // Se tiene que empezar por el scan para parar network-manager y tener informacion sobre la red que quieres // On doit toujours commencer par l'option scan pour stopper network-manager et récupérer les infos du réseau voulu.

____________________________________________________

EN/ES/FR good to know:


EN only: if you want to use this script with the fake page of your country you will need to change the filter in check.rb line 54





Date source //  Informaciones completo // Informations complètes:
EN: https://github.com/Koala633/hostbase/blob/master/hostbaseEnglishVersion/RogueAPparty.pdf

FR: http://www.crack-wifi.com/forum/topic-12236-hostbase-11-beta-test.html
FR: https://github.com/Koala633/hostbase/blob/master/hostbase/UnehistoirederogueAP.pdf

ES: # lien wifi libre a mettre hostbase-1.1
ES: https://www.wifi-libre.com/topic-756-una-historia-de-rogue-ap-el-pdf-de-koala-traducido-al-espanol.html

	 














