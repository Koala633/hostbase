#!/usr/bin/env ruby

require 'open3'
require 'highline/import'
require 'timeout'
require './state'




Timeout::timeout(0) { sleep(360); puts 'Clave no encontrado: réiniciando el ataque!' }

# XDo::Keyboard.char("ctrl+c") #=> sortie de hostbase

File.open("attack.txt").readlines.each do |attack|
puts attack
attack = attack.chomp
if File.read("attack.txt").include?('hostapd')
puts "Restarting hostapd attack..."
Dir.chdir '/tmp/hostbase-1.1'
sleep 1
`killall wpa_supplicant`
`airmon-ng stop wlan5mon`
sleep 5
`truncate -s 0 hostapd.txt`
sleep 1
Choice.attaque
else
puts "Restarting airbase-ng attack..."
Dir.chdir '/tmp/hostbase-1.1'
sleep 1
`killall wpa_supplicant`
`airmon-ng stop wlan5mon`
sleep 5
`truncate -s 0 hostapd.txt`
Choice.attaque
end
end
