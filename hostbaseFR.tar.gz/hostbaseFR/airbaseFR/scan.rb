#!/usr/bin/env ruby


require 'gtk2'
require 'open3'
require 'highline/import'


def error
puts "\e[1;31m[*] ERROR detected: check ALL your entry will abort in 5s.\e[0m"
sleep 5
abort("BYE..")
end


File.open("carte.txt").readlines.each do |carte|
   puts carte
$carte = carte.chomp
if carte.chomp.start_with?('wlan', 'wlx', 'wlp')
   puts "\e[1;32m[*] Wifi card is OK.\e[0m"
else
error()
end
end

puts "Arret de network-manager..."
`systemctl stop NetworkManager.service`
sleep 2
`systemctl disable NetworkManager.service`
sleep 4
puts "Starting monitor mode"
`airmon-ng start #{$carte}`
sleep 5 # Pour info les sleep sont important car sinon l'action n'a pas le temps de s'éxécuter et il y a erreur pa la suite
puts "\e[1;32m[*] Début du scan... ATTENDEZ 30s et laissez la fenetre de airodump ouverte après...\e[0m"
system "xterm -geometry '100x80' -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa #{$carte}mon &> /dev/null &"
sleep 30
puts "Scan terminado, re iniciando la tarjeta wifi"
`airmon-ng stop #{$carte}mon`
sleep 5
`ifconfig #{$carte} up`
puts "\e[1;32m[*] OK\e[0m"

