#!/usr/bin/env ruby
require 'gtk2'
require "highline/import"
require 'open3'
require 'monitor'
require './rogue'




def report_press(w); puts "Lauching (button) w=#{w}"; end

window = Gtk::Window.new(Gtk::Window::TOPLEVEL)
window.set_title  "Hostbase 1.1 by Koala"
window.border_width = 89
window.set_size_request(750, -1)

window.signal_connect('delete_event') { Gtk.main_quit }

nb = Gtk::Notebook.new
label1 = Gtk::Label.new("Scan")
label2 = Gtk::Label.new("WEP")
label3 = Gtk::Label.new("Airbase-ng")
label4 = Gtk::Label.new("Hostapd")
label5 = Gtk::Label.new("Airbase net access")
label6 = Gtk::Label.new("Hostapd multi AP")
label7 = Gtk::Label.new("Freeradius auth")
button = Gtk::Button.new("Discover the networks")
button1 = Gtk::Button.new("Airbase hirte attack")
button2 = Gtk::Button.new("Airbase open network")
button3 = Gtk::Button.new("Encrypted AP")
button4 = Gtk::Button.new("Rogue AP with internet and sergio proxy")
button5 = Gtk::Button.new("Hostapd Multi AP")
button6 = Gtk::Button.new("Use entreprise AP")


button.signal_connect("clicked")  {
dialog = Gtk::Dialog.new(
    "Wifi card for scan",
    nil,
    Gtk::Dialog::MODAL,
    [ Gtk::Stock::OK, Gtk::Dialog::RESPONSE_OK ],
    [ Gtk::Stock::CANCEL, Gtk::Dialog::RESPONSE_CANCEL ]
)
dialog.default_response = Gtk::Dialog::RESPONSE_OK
label1 = Gtk::Label.new("Wifi-card")

carte = Gtk::Entry.new

table = Gtk::Table.new(4, 2, false)
table.attach_defaults(label1, 0, 1, 0, 1)
table.attach_defaults(carte,   1, 2, 0, 1)

table.row_spacings = 5
table.column_spacings = 5
table.border_width = 10

dialog.vbox.add(table)
dialog.show_all

# Run the dialog and output the data if user okays it
dialog.run do |response|
case response
  when Gtk::Dialog::RESPONSE_OK
system "echo > carte.txt %s\n" % [carte.text] 
system "ruby scan.rb"
 end
end
dialog.signal_connect('response') { dialog.destroy }
}



button1.signal_connect("clicked")  {
dialog = Gtk::Dialog.new(
    "Use WEP to crack WPA",
    nil,
    Gtk::Dialog::MODAL,
    [ Gtk::Stock::OK, Gtk::Dialog::RESPONSE_OK ],
    [ Gtk::Stock::CANCEL, Gtk::Dialog::RESPONSE_CANCEL ]
)
dialog.default_response = Gtk::Dialog::RESPONSE_OK
label1 = Gtk::Label.new("Wifi-card")
label2 = Gtk::Label.new("SSID")
label3 = Gtk::Label.new("Your fake AP channel")
label4 = Gtk::Label.new("Your MAC adress")
label5 = Gtk::Label.new("Mac of target AP")
label6 = Gtk::Label.new("Channel of target AP")

carte = Gtk::Entry.new
nomreseau = Gtk::Entry.new
canal = Gtk::Entry.new
mac = Gtk::Entry.new
apmac = Gtk::Entry.new
apcanal = Gtk::Entry.new

table = Gtk::Table.new(4, 2, false)
table.attach_defaults(label1, 0, 1, 0, 1)
table.attach_defaults(label2, 0, 1, 1, 2)
table.attach_defaults(label3, 0, 1, 2, 3)
table.attach_defaults(label4, 0, 1, 3, 4) 
table.attach_defaults(label5, 0, 1, 4, 5)
table.attach_defaults(label6, 0, 1, 5, 6)
table.attach_defaults(carte,   1, 2, 0, 1)
table.attach_defaults(nomreseau,   1, 2, 1, 2)
table.attach_defaults(canal,   1, 2, 2, 3)
table.attach_defaults(mac,   1, 2, 3, 4)
table.attach_defaults(apmac,   1, 2, 4, 5)
table.attach_defaults(apcanal,   1, 2, 5, 6)
table.row_spacings = 5
table.column_spacings = 5
table.border_width = 10

dialog.vbox.add(table)
dialog.show_all

# Run the dialog and output the data if user okays it
dialog.run do |response|
case response
  when Gtk::Dialog::RESPONSE_OK
system "echo > carte.txt %s\n" % [carte.text] 
    system "echo > ssid.txt %s\n" % [nomreseau.text]
    system "echo > canal.txt %s\n" % [canal.text]
    system "echo > mac.txt %s\n" % [mac.text] 
    system "echo > apmac.txt %s\n" % [apmac.text] 
    system "echo > apcanal.txt %s\n" % [apcanal.text] 
Rogue.airbaseWep
  end
end
dialog.signal_connect('response') { dialog.destroy }
}




button2.signal_connect("clicked")  {
dialog = Gtk::Dialog.new(
    "Fake AP configuration",
    nil,
    Gtk::Dialog::MODAL,
    [ Gtk::Stock::OK, Gtk::Dialog::RESPONSE_OK ],
    [ Gtk::Stock::CANCEL, Gtk::Dialog::RESPONSE_CANCEL ]
)
dialog.default_response = Gtk::Dialog::RESPONSE_OK
label1 = Gtk::Label.new("Wifi-card")
label2 = Gtk::Label.new("SSID")
label3 = Gtk::Label.new("Your fake AP channel")
label4 = Gtk::Label.new("Network to phish")
label5 = Gtk::Label.new("Mac of target AP")
label6 = Gtk::Label.new("Channel of target AP")

carte = Gtk::Entry.new
nomreseau = Gtk::Entry.new
canal = Gtk::Entry.new
page = Gtk::Entry.new
apmac = Gtk::Entry.new
apcanal = Gtk::Entry.new

table = Gtk::Table.new(4, 2, false)
table.attach_defaults(label1, 0, 1, 0, 1)
table.attach_defaults(label2, 0, 1, 1, 2)
table.attach_defaults(label3, 0, 1, 2, 3)
table.attach_defaults(label4, 0, 1, 3, 4) 
table.attach_defaults(label5, 0, 1, 4, 5)
table.attach_defaults(label6, 0, 1, 5, 6)
table.attach_defaults(carte,   1, 2, 0, 1)
table.attach_defaults(nomreseau,   1, 2, 1, 2)
table.attach_defaults(canal,   1, 2, 2, 3)
table.attach_defaults(page,   1, 2, 3, 4)
table.attach_defaults(apmac,   1, 2, 4, 5)
table.attach_defaults(apcanal,   1, 2, 5, 6)
table.row_spacings = 5
table.column_spacings = 5
table.border_width = 10

dialog.vbox.add(table)
dialog.show_all

# Run the dialog and output the data if user okays it
dialog.run do |response|
case response
  when Gtk::Dialog::RESPONSE_OK
system "echo > carte.txt %s\n" % [carte.text] 
    system "echo > ssid.txt %s\n" % [nomreseau.text]
    system "echo > canal.txt %s\n" % [canal.text]
    system "echo > page.txt %s\n" % [page.text] 
    system "echo > apmac.txt %s\n" % [apmac.text] 
    system "echo > apcanal.txt %s\n" % [apcanal.text] 
Rogue.airbaseOpen
  end
end
dialog.signal_connect('response') { dialog.destroy }
}


button3.signal_connect("clicked")  {
dialog = Gtk::Dialog.new(
    "Fake AP configuration",
    nil,
    Gtk::Dialog::MODAL,
    [ Gtk::Stock::OK, Gtk::Dialog::RESPONSE_OK ],
    [ Gtk::Stock::CANCEL, Gtk::Dialog::RESPONSE_CANCEL ]
)
dialog.default_response = Gtk::Dialog::RESPONSE_OK
label1 = Gtk::Label.new("Wifi-card")
label2 = Gtk::Label.new("SSID")
label3 = Gtk::Label.new("Your fake AP channel")
label4 = Gtk::Label.new("Network to phish")
label5 = Gtk::Label.new("Mac of target AP")
label6 = Gtk::Label.new("Channel of target AP")

carte = Gtk::Entry.new
nomreseau = Gtk::Entry.new
canal = Gtk::Entry.new
page = Gtk::Entry.new
apmac = Gtk::Entry.new
apcanal = Gtk::Entry.new

table = Gtk::Table.new(4, 2, false)
table.attach_defaults(label1, 0, 1, 0, 1)
table.attach_defaults(label2, 0, 1, 1, 2)
table.attach_defaults(label3, 0, 1, 2, 3)
table.attach_defaults(label4, 0, 1, 3, 4) 
table.attach_defaults(label5, 0, 1, 4, 5)
table.attach_defaults(label6, 0, 1, 5, 6)
table.attach_defaults(carte,   1, 2, 0, 1)
table.attach_defaults(nomreseau,   1, 2, 1, 2)
table.attach_defaults(canal,   1, 2, 2, 3)
table.attach_defaults(page,   1, 2, 3, 4)
table.attach_defaults(apmac,   1, 2, 4, 5)
table.attach_defaults(apcanal,   1, 2, 5, 6)
table.row_spacings = 5
table.column_spacings = 5
table.border_width = 10

dialog.vbox.add(table)
dialog.show_all

# Run the dialog and output the data if user okays it
dialog.run do |response|
case response
  when Gtk::Dialog::RESPONSE_OK
system "echo > carte.txt %s\n" % [carte.text] 
    system "echo > ssid.txt %s\n" % [nomreseau.text]
    system "echo > canal.txt %s\n" % [canal.text]
    system "echo > page.txt %s\n" % [page.text] 
    system "echo > apmac.txt %s\n" % [apmac.text] 
    system "echo > apcanal.txt %s\n" % [apcanal.text] 
Rogue.hostapdNormal
end
end
dialog.signal_connect('response') { dialog.destroy }
}



button4.signal_connect("clicked")  {
dialog = Gtk::Dialog.new(
    "Fake AP configuration",
    nil,
    Gtk::Dialog::MODAL,
    [ Gtk::Stock::OK, Gtk::Dialog::RESPONSE_OK ],
    [ Gtk::Stock::CANCEL, Gtk::Dialog::RESPONSE_CANCEL ]
)
dialog.default_response = Gtk::Dialog::RESPONSE_OK
label1 = Gtk::Label.new("Wifi-card")
label2 = Gtk::Label.new("SSID")
label3 = Gtk::Label.new("Your fake AP channel")
label4 = Gtk::Label.new("Net card")
label5 = Gtk::Label.new("Gateway")
label6 = Gtk::Label.new("Mac of target AP")
label7 = Gtk::Label.new("Channel of target AP")

carte = Gtk::Entry.new
nomreseau = Gtk::Entry.new
canal = Gtk::Entry.new
cartenet = Gtk::Entry.new
passerelle = Gtk::Entry.new
apmac = Gtk::Entry.new
apcanal = Gtk::Entry.new

table = Gtk::Table.new(4, 2, false)
table.attach_defaults(label1, 0, 1, 0, 1)
table.attach_defaults(label2, 0, 1, 1, 2)
table.attach_defaults(label3, 0, 1, 2, 3)
table.attach_defaults(label4, 0, 1, 3, 4) 
table.attach_defaults(label5, 0, 1, 4, 5)
table.attach_defaults(label6, 0, 1, 5, 6)
table.attach_defaults(label7, 0, 1, 6, 7)
table.attach_defaults(carte,   1, 2, 0, 1)
table.attach_defaults(nomreseau,   1, 2, 1, 2)
table.attach_defaults(canal,   1, 2, 2, 3)
table.attach_defaults(cartenet,   1, 2, 3, 4)
table.attach_defaults(passerelle,   1, 2, 4, 5)
table.attach_defaults(apmac,   1, 2, 5, 6)
table.attach_defaults(apcanal,   1, 2, 6, 7)
table.row_spacings = 8
table.column_spacings = 8
table.border_width = 15

dialog.vbox.add(table)
dialog.show_all

# Run the dialog and output the data if user okays it
dialog.run do |response|
case response
  when Gtk::Dialog::RESPONSE_OK
system "echo > carte.txt %s\n" % [carte.text] 
    system "echo > ssid.txt %s\n" % [nomreseau.text]
    system "echo > canal.txt %s\n" % [canal.text]
    system "echo > cartenet.txt %s\n" % [cartenet.text] 
    system "echo > passerelle.txt %s\n" % [passerelle.text] 
    system "echo > apmac.txt %s\n" % [apmac.text] 
    system "echo > apcanal.txt %s\n" % [apcanal.text] 
Rogue.internetGratuit
end
end
dialog.signal_connect('response') { dialog.destroy }
}


button5.signal_connect("clicked")  {
dialog = Gtk::Dialog.new(
    "Fake AP configuration",
    nil,
    Gtk::Dialog::MODAL,
    [ Gtk::Stock::OK, Gtk::Dialog::RESPONSE_OK ],
    [ Gtk::Stock::CANCEL, Gtk::Dialog::RESPONSE_CANCEL ]
)
dialog.default_response = Gtk::Dialog::RESPONSE_OK
label1 = Gtk::Label.new("Wifi-card")
label2 = Gtk::Label.new("SSID")
label3 = Gtk::Label.new("Your fake AP channel")
label4 = Gtk::Label.new("Network to phish")
label5 = Gtk::Label.new("Mac of target AP")
label6 = Gtk::Label.new("Channel of target AP")

carte = Gtk::Entry.new
nomreseau = Gtk::Entry.new
canal = Gtk::Entry.new
page = Gtk::Entry.new
apmac = Gtk::Entry.new
apcanal = Gtk::Entry.new

table = Gtk::Table.new(4, 2, false)
table.attach_defaults(label1, 0, 1, 0, 1)
table.attach_defaults(label2, 0, 1, 1, 2)
table.attach_defaults(label3, 0, 1, 2, 3)
table.attach_defaults(label4, 0, 1, 3, 4) 
table.attach_defaults(label5, 0, 1, 4, 5)
table.attach_defaults(label6, 0, 1, 5, 6)
table.attach_defaults(carte,   1, 2, 0, 1)
table.attach_defaults(nomreseau,   1, 2, 1, 2)
table.attach_defaults(canal,   1, 2, 2, 3)
table.attach_defaults(page,   1, 2, 3, 4)
table.attach_defaults(apmac,   1, 2, 4, 5)
table.attach_defaults(apcanal,   1, 2, 5, 6)
table.row_spacings = 5
table.column_spacings = 5
table.border_width = 10

dialog.vbox.add(table)
dialog.show_all

# Run the dialog and output the data if user okays it
dialog.run do |response|
case response
  when Gtk::Dialog::RESPONSE_OK
system "echo > carte.txt %s\n" % [carte.text] 
    system "echo > ssid.txt %s\n" % [nomreseau.text]
    system "echo > canal.txt %s\n" % [canal.text]
    system "echo > page.txt %s\n" % [page.text] 
    system "echo > apmac.txt %s\n" % [apmac.text] 
    system "echo > apcanal.txt %s\n" % [apcanal.text] 
Rogue.hostapdMulti
end
end
dialog.signal_connect('response') { dialog.destroy }
}

button6.signal_connect("clicked")  {
dialog = Gtk::Dialog.new(
    "Fake AP configuration",
    nil,
    Gtk::Dialog::MODAL,
    [ Gtk::Stock::OK, Gtk::Dialog::RESPONSE_OK ],
    [ Gtk::Stock::CANCEL, Gtk::Dialog::RESPONSE_CANCEL ]
)
dialog.default_response = Gtk::Dialog::RESPONSE_OK
label1 = Gtk::Label.new("Wifi-card")
label2 = Gtk::Label.new("SSID")
label3 = Gtk::Label.new("Your fake AP channel")
label4 = Gtk::Label.new("Mac of target AP")
label5 = Gtk::Label.new("Channel of target AP")

carte = Gtk::Entry.new
nomreseau = Gtk::Entry.new
canal = Gtk::Entry.new
apmac = Gtk::Entry.new
apcanal = Gtk::Entry.new

table = Gtk::Table.new(4, 2, false)
table.attach_defaults(label1, 0, 1, 0, 1)
table.attach_defaults(label2, 0, 1, 1, 2)
table.attach_defaults(label3, 0, 1, 2, 3)
table.attach_defaults(label4, 0, 1, 3, 4) 
table.attach_defaults(label5, 0, 1, 4, 5)
table.attach_defaults(carte,   1, 2, 0, 1)
table.attach_defaults(nomreseau,   1, 2, 1, 2)
table.attach_defaults(canal,   1, 2, 2, 3)
table.attach_defaults(apmac,   1, 2, 3, 4)
table.attach_defaults(apcanal,   1, 2, 4, 5)
table.row_spacings = 5
table.column_spacings = 5
table.border_width = 10

dialog.vbox.add(table)
dialog.show_all

# Run the dialog and output the data if user okays it
dialog.run do |response|
case response
  when Gtk::Dialog::RESPONSE_OK
system "echo > carte.txt %s\n" % [carte.text] 
    system "echo > ssid.txt %s\n" % [nomreseau.text] 
    system "echo > canal.txt %s\n" % [canal.text] 
    system "echo > apmac.txt %s\n" % [apmac.text] 
    system "echo > apcanal.txt %s\n" % [apcanal.text] 
Rogue.hostapdFreeradius
end
end
dialog.signal_connect('response') { dialog.destroy }
}


nb.signal_connect('change-current-page') { another_tab }

nb.append_page(button, label1)
nb.append_page(button1, label2)
nb.append_page(button2, label3)
nb.append_page(button3, label4)
nb.append_page(button4, label5)
nb.append_page(button5, label6)
nb.append_page(button6, label7)


window.add(nb)
window.show_all
Gtk.main
