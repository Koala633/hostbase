#!/usr/bin/env ruby


require 'gtk2'
require 'open3'
require 'highline/import'



def error
puts "ERROR entry detected: check ALL your entries, will abort in 5s !"
sleep 5
abort("BYE..")
end



File.open("apcanal.txt").readlines.each do |apcanal|
   puts apcanal
$apcanal = apcanal.chomp
if apcanal.chomp.to_i.between?(1, 13)
   puts "\e[1;32m[*] Ap channel is OK.\e[0m"
else
error()
end
end

File.open("apmac.txt").readlines.each do |apmac|
   puts apmac
$apmac = apmac.chomp
if apmac.chomp =~ /^([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}$/i
   puts "\e[1;32m[*] Ap mac is OK.\e[0m"
else
error()
end
end


File.open("carte.txt").readlines.each do |carte|
   puts carte
$carte = carte.chomp
if carte.chomp.start_with?('wlan', 'wlx', 'wlp')
   puts "\e[1;32m[*] Wifi card is OK.\e[0m"
else
error()
end
end



cartenet = File.open("cartenet.txt").readlines.each do |cartenet|
  puts cartenet
$cartenet = cartenet.chomp
if cartenet.chomp.start_with?('eth', 'br', 'wlan', 'wl')
   puts "\e[1;32m[*] Internet card is OK.\e[0m"
else
error()
end
end

File.open("canal.txt").readlines.each do |canal|
   puts canal
$canal = canal.chomp
if canal.chomp.to_i.between?(1, 13)
   puts "\e[1;32m[*] Ap channel is OK.\e[0m"
else
error()
end
end


File.open("ssid.txt").readlines.each do |ssid|
   puts ssid
$ssid = ssid.chomp


File.open("passerelle.txt").readlines.each do |passerelle|
   puts passerelle
$passerelle = passerelle.chomp
if passerelle.chomp.start_with?('192.168', '172', '10')
   puts "\e[1;32m[*] Gateway is OK.\e[0m"
else
error()
end
end
end

