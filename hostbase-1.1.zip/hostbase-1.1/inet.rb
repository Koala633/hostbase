#!/usr/bin/env ruby


require 'gtk2'
require 'open3'
require 'highline/import'



def error
puts "ERROR : verifica tu datos, el script se va a para dentro 5s !"
sleep 5
abort("BYE..")
end



File.open("apcanal.txt").readlines.each do |apcanal|
   puts apcanal
$apcanal = apcanal.chomp
if apcanal.chomp.to_i.between?(1, 13)
   puts "\e[1;32m[*] Ap canal esta BUENO.\e[0m"
else
error()
end
end

File.open("apmac.txt").readlines.each do |apmac|
   puts apmac
$apmac = apmac.chomp
if apmac.chomp =~ /^([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}$/i
   puts "\e[1;32m[*] Ap mac esta BUENO.\e[0m"
else
error()
end
end


File.open("carte.txt").readlines.each do |carte|
   puts carte
$carte = carte.chomp
if carte.chomp.start_with?('wlan', 'wlx', 'wlp')
   puts "\e[1;32m[*] Tajeta wifi BUENA.\e[0m"
else
error()
end
end



cartenet = File.open("cartenet.txt").readlines.each do |cartenet|
  puts cartenet
$cartenet = cartenet.chomp
if cartenet.chomp.start_with?('eth', 'br', 'wlan', 'wl', 'enp')
   puts "\e[1;32m[*] Tajeta conectado a internet BUENA. \e[0m"
else
error()
end
end

File.open("canal.txt").readlines.each do |canal|
   puts canal
$canal = canal.chomp
if canal.chomp.to_i.between?(1, 13)
   puts "\e[1;32m[*] canal de tu AP esta BUENO.\e[0m"
else
error()
end
end


File.open("ssid.txt").readlines.each do |ssid|
   puts ssid
$ssid = ssid.chomp


File.open("passerelle.txt").readlines.each do |passerelle|
   puts passerelle
$passerelle = passerelle.chomp
if passerelle.chomp.start_with?('192.168', '172', '10')
   puts "\e[1;32m[*] Gateway BUENO.\e[0m"
else
error()
end
end
end

