
~~~~~~~~~~~~~~~~~~ Hostbase project By Koala @ crack-wifi.com @ wifi-libre.com @ kali-linux.fr ~~~~~~~~~~~~~~~~~~~~

 Bienvenido en hostbase

Readme hecho ara los usarios de kali-linux.El script anda bien sobre kali-linux xfce presicamente

PARA TODOS DEPENDENCIAS DEL SCRIPT

apt-get install -y build-essential upgrade-system subversion wget g++ iptables iptables-dev pavucontrol ffmpeg sqlite3 libsqlite3-dev libssl-dev libnl-3-dev libnl-genl-3-dev dsniff hostapd isc-dhcp-server pkg-config xterm freeradius apache2 php libapache2-mod-php php-mcrypt php-cli tcpdump scapy vokoscreen wireshark python-twisted bridge-utils devscripts gengetopt autoconf libtool make

____________________________________________

Para usar el modo multi AP o combo se necesita compilar bien hostapd.Si tienes una version de hostapd antigua suprima lo:
apt-get remove hostapd

Y compila lo asi:

wget http://hostap.epitest.fi/releases/hostapd-2.6.tar.gz
tar -zxf hostapd-2.6.tar.gz
cd /root/hostapd-2.6/hostapd
cp defconfig .config
nano .config

Decomentar el # en todas las opciones que siguen:

CONFIG_DRIVER_NL80211=y
CONFIG_LIBNL32=y
CONFIG_EAP_PWD=y
CONFIG_WPS=y
CONFIG_WPS_UPNP=y
CONFIG_WPS_NFC=y
CONFIG_RADIUS_SERVER=y
CONFIG_IEEE80211N=y
CONFIG_IEEE80211AC=y
CONFIG_DEBUG_FILE=y
CONFIG_FULL_DYNAMIC_VLAN=y
CONFIG_TLSV11=y
CONFIG_TAXONOMY=y


Y termina con:

sudo make
sudo make install
hostapd -v

________________________________________________

Servidor web apache2: se copia el fichero 000-default.conf a dentro el archivo de hostbase en /etc/apache2/site-available.Para terminar se copia el fichero apache2.conf en /etc/apache2

Se copia todo lo que hay en la carpeta paginasAQUI a dentro el répertorio /etc  (son las falsas paginas de phishing)

________________________________________________


Installar las dependencias de los gems de ruby:


apt-get install ruby
apt-get install ruby-dev
gem install highline
gem install rake
gem install bundler
apt-get install libgtk2.0-dev
gem install gtk2






_________________________________________________

EN/ES/FR start:

El script se tiene que ejecutar en la carpeta /tmp
Copia y pega la carpeta entera de hostbase-1.1 a dentro la carpeta /tmp

A dentro /tmp/hostbase-1.1 click derecho, abrir un terminal aqui

 Inicia lo asi //
ruby hostbase.rb

Por la version facil es igual, copia la carpeta airbase en /tmp y abra un terminal a dentro /tmp/airbase
 Inicia lo assi //
ruby airbase.rb


--> OJO: no olvidas de empezar por el scan de redes para apagar network-manager <--


____________________________________________________


Para mas potentia este script ANDA con 2 tarjeta wifi porqué automatisa un monton de cosas: el AP encryptado con el WPS, la DoS que sigue el Ap etc...

--> Se tiene que empezar por el scan de redes para parar network-manager y tener informacion sobre la red que quieres

____________________________________________________




Date source //  Informaciones completo // Informations complètes:
EN: https://github.com/Koala633/hostbase/blob/master/hostbaseEnglishVersion/RogueAPparty.pdf

FR: http://www.crack-wifi.com/forum/topic-12236-hostbase-11-beta-test.html
FR: https://github.com/Koala633/hostbase/blob/master/hostbase/UnehistoirederogueAP.pdf

ES: # lien wifi libre a mettre hostbase-1.1
ES: https://www.wifi-libre.com/topic-756-una-historia-de-rogue-ap-el-pdf-de-koala-traducido-al-espanol.html

	 














