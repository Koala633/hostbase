#!/usr/bin/env ruby


require 'gtk2'
require 'open3'
require 'highline/import'




system "airmon-ng >> airmonng.txt"

File.open("airmonng.txt").readlines.each do |line|
  if line =~ /ath/
nil
else
puts "\e[1;31m[*] ERROR: No hay atheros chipset, hostapd necesita atheros para andar ! usa airbase-ng\e[0m"
end
end


system "gem list > gemlist.txt"
File.open("gemlist.txt").readlines.each do |gem|
if File.read("gemlist.txt").include? ('gtk2') && ('highline')
nil
else
puts "\e[1;31m[*] ERROR: No hay todos los ruby gem instalado en tu systemo !\e[0m"
end
end


if Dir.exists?('/var/www/html')
puts "\e[1;31m[*] ERROR: El servidor apache2 necesita configuraciones: DocumentRoot /var/www/, mira eso en /etc/apache2/sites-enabled/000-default.conf\e[0m"
else
nil
end


system "ps aux | grep network-manager > net.txt"
File.open("net.txt").readlines.each do |net|
if File.zero?("net.txt")
nil
else
puts "\e[1;31m[*] ERROR: network-manager no tiene que estar iniciando para usar hostapd !\e[0m"
end
end


system "ruby -v > version.txt"
File.open("version.txt").readlines.each do |net|
if File.read("version.txt").include? ('ruby 2.3.6p384 (2017-12-14) [x86_64-linux-gnu]')
nil
else
puts "\e[1;32m[*] INFO: La version de ruby que tienes no es la misma que el que usa el script, no hay mucho diferencia pero tienes que checkear tu version.\e[0m"
end
end


puts "\e[1;32m[*] INFO: Un fichero process.txt ha sido creado en esta misma, si hay un problemo se tiene que dar el contenido de este fichero en wifi-libre con las errores de este terminal\e[0m"
system "ps -ef > process.txt"
sleep 1























