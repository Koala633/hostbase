Put all the recipients of this folder on /var/www

Don't forget to change the SSID, MAC, IP, status of client profile and go down to put the adress MAC of the victim connected to our network.

All change to do are in the same page, index.php for "XX" value.
