#!/usr/bin/env ruby
require 'gtk2'
require "highline/import"
require 'open3'
require 'monitor'
require './rogue'




def report_press(w); puts "Lauching (button) w=#{w}"; end

window = Gtk::Window.new(Gtk::Window::TOPLEVEL)
window.set_title  "Hostbase 1.2 par Koala"
window.border_width = 89
window.set_size_request(600, -1)

window.signal_connect('delete_event') { Gtk.main_quit }

nb = Gtk::Notebook.new
label1 = Gtk::Label.new("Scan")
label2 = Gtk::Label.new("Hostapd multi AP")
label3 = Gtk::Label.new("Hostapd WPA")
button = Gtk::Button.new("Découvrir les réseaux")
button1 = Gtk::Button.new("Hostapd Multi AP attaquer 1 réseau avec 3 fakes AP ouvert et un filtrage MAC")
button2 = Gtk::Button.new("Attaquer 1 AP avec le WPA/2 et une page de phishing")

button.signal_connect("clicked")  {
dialog = Gtk::Dialog.new(
    "Carte wifi de scan",
    nil,
    Gtk::Dialog::MODAL,
    [ Gtk::Stock::OK, Gtk::Dialog::RESPONSE_OK ],
    [ Gtk::Stock::CANCEL, Gtk::Dialog::RESPONSE_CANCEL ]
)
dialog.default_response = Gtk::Dialog::RESPONSE_OK
label1 = Gtk::Label.new("Carte")

carte = Gtk::Entry.new

table = Gtk::Table.new(4, 2, false)
table.attach_defaults(label1, 0, 1, 0, 1)
table.attach_defaults(carte,   1, 2, 0, 1)

table.row_spacings = 5
table.column_spacings = 5
table.border_width = 10

dialog.vbox.add(table)
dialog.show_all

# Run the dialog and output the data if user okays it
dialog.run do |response|
case response
  when Gtk::Dialog::RESPONSE_OK
system "echo > carte.txt %s\n" % [carte.text] 
system "ruby scan.rb"
 end
end
dialog.signal_connect('response') { dialog.destroy }
}



button1.signal_connect("clicked")  {
dialog = Gtk::Dialog.new(
    "Fake AP configuration",
    nil,
    Gtk::Dialog::MODAL,
    [ Gtk::Stock::OK, Gtk::Dialog::RESPONSE_OK ],
    [ Gtk::Stock::CANCEL, Gtk::Dialog::RESPONSE_CANCEL ]
)
dialog.default_response = Gtk::Dialog::RESPONSE_OK
label1 = Gtk::Label.new("Carte")
label2 = Gtk::Label.new("SSID")
label3 = Gtk::Label.new("Canal du fake AP")
label4 = Gtk::Label.new("Page de phishing")
label5 = Gtk::Label.new("Bssid de l'AP ciblé")
label6 = Gtk::Label.new("Canal de l'AP ciblé")
label7 = Gtk::Label.new("Client 1")
label8 = Gtk::Label.new("Client 2")
label9 = Gtk::Label.new("Client 3")



carte = Gtk::Entry.new
nomreseau = Gtk::Entry.new
canal = Gtk::Entry.new
page = Gtk::Entry.new
apmac = Gtk::Entry.new
apcanal = Gtk::Entry.new
mac1ssid1 = Gtk::Entry.new
mac2ssid1 = Gtk::Entry.new
mac3ssid1 = Gtk::Entry.new

table = Gtk::Table.new(4, 2, false)
table.attach_defaults(label1, 0, 1, 0, 1)
table.attach_defaults(label2, 0, 1, 1, 2)
table.attach_defaults(label3, 0, 1, 2, 3)
table.attach_defaults(label4, 0, 1, 3, 4) 
table.attach_defaults(label5, 0, 1, 4, 5)
table.attach_defaults(label6, 0, 1, 5, 6)
table.attach_defaults(label7, 0, 1, 6, 7) 
table.attach_defaults(label8, 0, 1, 7, 8)
table.attach_defaults(label9, 0, 1, 8, 9)
table.attach_defaults(carte,   1, 2, 0, 1)
table.attach_defaults(nomreseau,   1, 2, 1, 2)
table.attach_defaults(canal,   1, 2, 2, 3)
table.attach_defaults(page,   1, 2, 3, 4)
table.attach_defaults(apmac,   1, 2, 4, 5)
table.attach_defaults(apcanal,   1, 2, 5, 6)
table.attach_defaults(mac1ssid1,   1, 2, 6, 7)
table.attach_defaults(mac2ssid1,   1, 2, 7, 8)
table.attach_defaults(mac3ssid1,   1, 2, 8, 9)
table.row_spacings = 5
table.column_spacings = 5
table.border_width = 10

dialog.vbox.add(table)
dialog.show_all

# Run the dialog and output the data if user okays it
dialog.run do |response|
case response
  when Gtk::Dialog::RESPONSE_OK
system "echo > carte.txt %s\n" % [carte.text] 
    system "echo > ssid.txt %s\n" % [nomreseau.text]
    system "echo > canal.txt %s\n" % [canal.text]
    system "echo > page.txt %s\n" % [page.text] 
    system "echo > apmac.txt %s\n" % [apmac.text] 
    system "echo > apcanal.txt %s\n" % [apcanal.text]
    system "echo > mac1ssid1.txt %s\n" % [mac1ssid1.text]
    system "echo > mac2ssid1.txt %s\n" % [mac2ssid1.text]
    system "echo > mac3ssid1.txt %s\n" % [mac3ssid1.text] 
Rogue.toutEnun 
  end
end
dialog.signal_connect('response') { dialog.destroy }
}


button2.signal_connect("clicked")  {
dialog = Gtk::Dialog.new(
    "Configuration du fake AP",
    nil,
    Gtk::Dialog::MODAL,
    [ Gtk::Stock::OK, Gtk::Dialog::RESPONSE_OK ],
    [ Gtk::Stock::CANCEL, Gtk::Dialog::RESPONSE_CANCEL ]
)
dialog.default_response = Gtk::Dialog::RESPONSE_OK
label1 = Gtk::Label.new("Carte")
label2 = Gtk::Label.new("SSID")
label3 = Gtk::Label.new("Canal du fake AP")
label4 = Gtk::Label.new("Page de phishing")
label5 = Gtk::Label.new("Bssid de l'AP ciblé")
label6 = Gtk::Label.new("Canal de l'AP ciblé")

carte = Gtk::Entry.new
nomreseau = Gtk::Entry.new
canal = Gtk::Entry.new
page = Gtk::Entry.new
apmac = Gtk::Entry.new
apcanal = Gtk::Entry.new

table = Gtk::Table.new(4, 2, false)
table.attach_defaults(label1, 0, 1, 0, 1)
table.attach_defaults(label2, 0, 1, 1, 2)
table.attach_defaults(label3, 0, 1, 2, 3)
table.attach_defaults(label4, 0, 1, 3, 4) 
table.attach_defaults(label5, 0, 1, 4, 5)
table.attach_defaults(label6, 0, 1, 5, 6)
table.attach_defaults(carte,   1, 2, 0, 1)
table.attach_defaults(nomreseau,   1, 2, 1, 2)
table.attach_defaults(canal,   1, 2, 2, 3)
table.attach_defaults(page,   1, 2, 3, 4)
table.attach_defaults(apmac,   1, 2, 4, 5)
table.attach_defaults(apcanal,   1, 2, 5, 6)
table.row_spacings = 5
table.column_spacings = 5
table.border_width = 10

dialog.vbox.add(table)
dialog.show_all

# Run the dialog and output the data if user okays it
dialog.run do |response|
case response
  when Gtk::Dialog::RESPONSE_OK
system "echo > carte.txt %s\n" % [carte.text] 
    system "echo > ssid.txt %s\n" % [nomreseau.text]
    system "echo > canal.txt %s\n" % [canal.text]
    system "echo > page.txt %s\n" % [page.text] 
    system "echo > apmac.txt %s\n" % [apmac.text] 
    system "echo > apcanal.txt %s\n" % [apcanal.text] 
Rogue.hostapdNormal 
end
end
dialog.signal_connect('response') { dialog.destroy }
}



nb.signal_connect('change-current-page') { another_tab }

nb.append_page(button, label1)
nb.append_page(button1, label2)
nb.append_page(button2, label3)
window.add(nb)
window.show_all
Gtk.main
